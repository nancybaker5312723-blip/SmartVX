import React from "react";
import { StyleSheet, View, Dimensions, Platform } from 'react-native';
import { Tabs } from "expo-router";
import { FontAwesome5, FontAwesome6 } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';


export default function Layout() {
  return (
    <Tabs 
      backBehavior="order"
      screenOptions={{ 
          tabBarActiveTintColor: "#165DFF",
          tabBarInactiveTintColor: "#86909C",
          tabBarStyle: {
            backgroundColor: "#FFFFFF"
          }
      }}>

        <Tabs.Screen
            name="index"
            options={{href: null}}
        />

        <Tabs.Screen name="p-home" options={{
            title: '主页', 
            headerShown: false,
            tabBarIcon: ({ color }) => (
                <FontAwesome6 name="house" size={20} color={color} />
            )
        }}/>

        <Tabs.Screen name="p-persona_library" options={{
            title: '人设', 
            headerShown: false,
            tabBarIcon: ({ color }) => (
                <FontAwesome6 name="user-group" size={20} color={color} />
            )
        }}/>

        <Tabs.Screen name="p-object_list" options={{
            title: '对象', 
            headerShown: false,
            tabBarIcon: ({ color }) => (
                <FontAwesome6 name="address-book" size={20} color={color} />
            )
        }}/>

        <Tabs.Screen name="p-settings" options={{
            title: '设置', 
            headerShown: false,
            tabBarIcon: ({ color }) => (
                <FontAwesome6 name="gear" size={20} color={color} />
            )
        }}/>
    </Tabs>
  );
}