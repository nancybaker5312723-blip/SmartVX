import React from 'react';
import { Redirect } from "expo-router";

const Index = () => {
  return <Redirect href="/p-home" />;
};
export default Index;