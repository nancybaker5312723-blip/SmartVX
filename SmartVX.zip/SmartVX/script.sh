npx npm i expo-clipboard --save
