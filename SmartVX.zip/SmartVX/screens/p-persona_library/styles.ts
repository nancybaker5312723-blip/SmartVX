

import { StyleSheet, Platform } from 'react-native';

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F3F5',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 16,
  },
  titleSection: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  titleIcon: {
    width: 32,
    height: 32,
    backgroundColor: '#165DFF',
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1D2129',
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  filterButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F7F8FA',
    justifyContent: 'center',
    alignItems: 'center',
  },
  createButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#165DFF',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 4,
  },
  createButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  filterPanel: {
    paddingHorizontal: 24,
    marginBottom: 16,
  },
  filterCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    padding: 16,
    borderWidth: 1,
    borderColor: '#E5E6EB',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 2,
      },
      android: {
        elevation: 1,
      },
    }),
  },
  filterSection: {
    marginBottom: 16,
  },
  filterLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#4E5969',
    marginBottom: 8,
  },
  filterTags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  filterTag: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 16,
    backgroundColor: '#F7F8FA',
    borderWidth: 1,
    borderColor: '#E5E6EB',
  },
  filterTagActive: {
    backgroundColor: '#165DFF',
    borderColor: '#165DFF',
  },
  filterTagText: {
    fontSize: 14,
    color: '#4E5969',
  },
  filterTagTextActive: {
    color: '#FFFFFF',
  },
  resetButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    backgroundColor: '#F7F8FA',
    borderRadius: 4,
    gap: 8,
  },
  resetButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
  },
  personaList: {
    paddingHorizontal: 24,
    paddingBottom: 20,
  },
  personaSection: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1D2129',
    marginBottom: 12,
  },
  personaCards: {
    gap: 12,
  },
  personaCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    padding: 16,
    borderWidth: 1,
    borderColor: '#E5E6EB',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 2,
      },
      android: {
        elevation: 1,
      },
    }),
  },
  personaHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  personaInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  personaAvatar: {
    width: 40,
    height: 40,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  personaDetails: {
    flex: 1,
  },
  personaName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1D2129',
    marginBottom: 2,
  },
  personaDescription: {
    fontSize: 14,
    color: '#4E5969',
  },
  personaBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  globalBadge: {
    backgroundColor: 'rgba(22, 93, 255, 0.1)',
  },
  categoryBadge: {
    backgroundColor: 'rgba(249, 115, 22, 0.1)',
  },
  personaBadgeText: {
    fontSize: 12,
    fontWeight: '500',
  },
  globalBadgeText: {
    color: '#165DFF',
  },
  categoryBadgeText: {
    color: '#F97316',
  },
  personaExample: {
    backgroundColor: '#F7F8FA',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
  },
  personaExampleText: {
    fontSize: 14,
    color: '#4E5969',
    fontStyle: 'italic',
  },
  personaFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  personaStats: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statText: {
    fontSize: 12,
    color: '#86909C',
  },
  applyButton: {
    backgroundColor: '#165DFF',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 4,
  },
  applyButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    padding: 24,
    width: '100%',
    maxWidth: 400,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1D2129',
    marginBottom: 16,
  },
  modalDescription: {
    fontSize: 14,
    color: '#4E5969',
    marginBottom: 24,
  },
  applicationOptions: {
    gap: 12,
    marginBottom: 24,
  },
  applicationOption: {
    borderWidth: 1,
    borderColor: '#E5E6EB',
    borderRadius: 8,
    padding: 12,
  },
  applicationOptionContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  applicationOptionLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  applicationOptionText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1D2129',
  },
  modalActions: {
    flexDirection: 'row',
    gap: 12,
  },
  modalCancelButton: {
    flex: 1,
    backgroundColor: '#F7F8FA',
    paddingVertical: 8,
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalCancelButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1D2129',
  },
  modalConfirmButton: {
    flex: 1,
    backgroundColor: '#165DFF',
    paddingVertical: 8,
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalConfirmButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#FFFFFF',
  },
  toast: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: [{ translateX: -100 }, { translateY: -20 }],
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
    zIndex: 1000,
    minWidth: 200,
    alignItems: 'center',
  },
  toastText: {
    color: '#FFFFFF',
    fontSize: 14,
    textAlign: 'center',
  },
});

