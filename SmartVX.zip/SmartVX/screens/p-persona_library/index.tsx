

import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, Modal, Alert, } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { FontAwesome6 } from '@expo/vector-icons';
import styles from './styles';

interface Persona {
  id: string;
  name: string;
  description: string;
  avatar: string;
  avatarColor: string;
  example: string;
  usageCount: number;
  adoptionRate: number;
  isGlobal?: boolean;
  category?: string;
}

interface FilterState {
  tone: string[];
  length: string[];
  emoji: string[];
  scene: string[];
}

const PersonaLibraryScreen = () => {
  const router = useRouter();
  const [isFilterPanelExpanded, setIsFilterPanelExpanded] = useState(false);
  const [isApplicationModalVisible, setIsApplicationModalVisible] = useState(false);
  const [selectedPersonaId, setSelectedPersonaId] = useState<string | null>(null);
  const [selectedApplicationType, setSelectedApplicationType] = useState<string | null>(null);
  const [isToastVisible, setIsToastVisible] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  
  const [activeFilters, setActiveFilters] = useState<FilterState>({
    tone: [],
    length: [],
    emoji: [],
    scene: [],
  });

  const [personas] = useState<Persona[]>([
    {
      id: 'persona-warm-classmate',
      name: '暖心同学',
      description: '温柔体贴，善解人意',
      avatar: 'heart',
      avatarColor: '#EC4899',
      example: '今天天气不错呢，要不要一起出去走走？😊',
      usageCount: 12,
      adoptionRate: 85,
      isGlobal: true,
    },
    {
      id: 'persona-stable-colleague',
      name: '稳重同事',
      description: '专业严谨，条理清晰',
      avatar: 'briefcase',
      avatarColor: '#3B82F6',
      example: '关于项目进度，我建议我们可以安排一次简短的会议来同步最新情况。',
      usageCount: 8,
      adoptionRate: 92,
    },
    {
      id: 'persona-energetic-friend',
      name: '元气伙伴',
      description: '活泼开朗，充满活力',
      avatar: 'sun',
      avatarColor: '#F59E0B',
      example: '太棒了！我们一起去尝试那家新开的餐厅吧！🎉',
      usageCount: 6,
      adoptionRate: 78,
      category: '小雨',
    },
    {
      id: 'persona-professional-assistant',
      name: '专业助理',
      description: '高效专业，逻辑清晰',
      avatar: 'user-tie',
      avatarColor: '#8B5CF6',
      example: '根据您的需求，我为您整理了三个可行的方案，请您过目。',
      usageCount: 4,
      adoptionRate: 95,
    },
    {
      id: 'persona-custom-casual',
      name: '随性朋友',
      description: '轻松随意，自然聊天',
      avatar: 'user-pen',
      avatarColor: '#F97316',
      example: '都行啊，我没什么特别的想法，你定就好~',
      usageCount: 3,
      adoptionRate: 80,
      category: '自定义',
    },
  ]);

  const filterOptions = {
    tone: ['轻松', '认真', '幽默', '礼貌', '直接', '亲密'],
    length: ['短', '中', '长'],
    emoji: ['低', '中', '高'],
    scene: ['破冰', '续聊', '邀约', '道歉', '冲突'],
  };

  const handleFilterToggle = (filterType: keyof FilterState, value: string) => {
    setActiveFilters(prev => {
      const newFilters = { ...prev };
      const currentValues = newFilters[filterType];
      
      if (currentValues.includes(value)) {
        newFilters[filterType] = currentValues.filter(v => v !== value);
      } else {
        newFilters[filterType] = [...currentValues, value];
      }
      
      return newFilters;
    });
  };

  const handleResetFilters = () => {
    setActiveFilters({
      tone: [],
      length: [],
      emoji: [],
      scene: [],
    });
  };

  const handleFilterPanelToggle = () => {
    setIsFilterPanelExpanded(!isFilterPanelExpanded);
  };

  const handleCreatePersona = () => {
    router.push('/p-custom_persona_editor');
  };

  const handleApplyPersona = (personaId: string) => {
    setSelectedPersonaId(personaId);
    setIsApplicationModalVisible(true);
    setSelectedApplicationType(null);
  };

  const handleApplicationTypeSelect = (type: string) => {
    if (type === 'contact') {
      router.push('/p-object_list');
    } else if (type === 'scene') {
      showToast('场景应用功能开发中');
    } else {
      setSelectedApplicationType(type);
    }
  };

  const handleConfirmApplication = () => {
    if (!selectedApplicationType) {
      showToast('请选择应用范围');
      return;
    }

    setIsApplicationModalVisible(false);
    showToast('人设已应用');
  };

  const handleCancelApplication = () => {
    setIsApplicationModalVisible(false);
  };

  const showToast = (message: string) => {
    setToastMessage(message);
    setIsToastVisible(true);
    setTimeout(() => {
      setIsToastVisible(false);
    }, 2000);
  };

  const renderFilterTag = (filterType: keyof FilterState, value: string) => {
    const isActive = activeFilters[filterType].includes(value);
    
    return (
      <TouchableOpacity
        key={`${filterType}-${value}`}
        style={[styles.filterTag, isActive && styles.filterTagActive]}
        onPress={() => handleFilterToggle(filterType, value)}
      >
        <Text style={[styles.filterTagText, isActive && styles.filterTagTextActive]}>
          {value}
        </Text>
      </TouchableOpacity>
    );
  };

  const renderPersonaCard = (persona: Persona) => (
    <View key={persona.id} style={styles.personaCard}>
      <View style={styles.personaHeader}>
        <View style={styles.personaInfo}>
          <View style={[styles.personaAvatar, { backgroundColor: `${persona.avatarColor}20` }]}>
            <FontAwesome6 name={persona.avatar} size={16} color={persona.avatarColor} />
          </View>
          <View style={styles.personaDetails}>
            <Text style={styles.personaName}>{persona.name}</Text>
            <Text style={styles.personaDescription}>{persona.description}</Text>
          </View>
        </View>
        {(persona.isGlobal || persona.category) && (
          <View style={[
            styles.personaBadge,
            persona.isGlobal ? styles.globalBadge : styles.categoryBadge
          ]}>
            <Text style={[
              styles.personaBadgeText,
              persona.isGlobal ? styles.globalBadgeText : styles.categoryBadgeText
            ]}>
              {persona.isGlobal ? '全局' : persona.category}
            </Text>
          </View>
        )}
      </View>
      
      <View style={styles.personaExample}>
        <Text style={styles.personaExampleText}>{persona.example}</Text>
      </View>
      
      <View style={styles.personaFooter}>
        <View style={styles.personaStats}>
          <View style={styles.statItem}>
            <FontAwesome6 name="comment" size={10} color="#86909C" />
            <Text style={styles.statText}>使用 {persona.usageCount} 次</Text>
          </View>
          <View style={styles.statItem}>
            <FontAwesome6 name="circle-check" size={10} color="#86909C" />
            <Text style={styles.statText}>采纳率 {persona.adoptionRate}%</Text>
          </View>
        </View>
        <TouchableOpacity
          style={styles.applyButton}
          onPress={() => handleApplyPersona(persona.id)}
        >
          <Text style={styles.applyButtonText}>应用</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* 顶部导航 */}
        <View style={styles.header}>
          <View style={styles.titleSection}>
            <View style={styles.titleIcon}>
              <FontAwesome6 name="user-group" size={16} color="#FFFFFF" />
            </View>
            <Text style={styles.title}>人设库</Text>
          </View>
          <View style={styles.headerActions}>
            <TouchableOpacity
              style={styles.filterButton}
              onPress={handleFilterPanelToggle}
            >
              <FontAwesome6 
                name={isFilterPanelExpanded ? "xmark" : "filter"} 
                size={16} 
                color="#4E5969" 
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.createButton}
              onPress={handleCreatePersona}
            >
              <FontAwesome6 name="plus" size={12} color="#FFFFFF" />
              <Text style={styles.createButtonText}>新建</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* 筛选面板 */}
        {isFilterPanelExpanded && (
          <View style={styles.filterPanel}>
            <View style={styles.filterCard}>
              {/* 语气筛选 */}
              <View style={styles.filterSection}>
                <Text style={styles.filterLabel}>语气</Text>
                <View style={styles.filterTags}>
                  {filterOptions.tone.map(value => renderFilterTag('tone', value))}
                </View>
              </View>
              
              {/* 长度筛选 */}
              <View style={styles.filterSection}>
                <Text style={styles.filterLabel}>回复长度</Text>
                <View style={styles.filterTags}>
                  {filterOptions.length.map(value => renderFilterTag('length', value))}
                </View>
              </View>
              
              {/* Emoji密度筛选 */}
              <View style={styles.filterSection}>
                <Text style={styles.filterLabel}>Emoji密度</Text>
                <View style={styles.filterTags}>
                  {filterOptions.emoji.map(value => renderFilterTag('emoji', value))}
                </View>
              </View>
              
              {/* 场景筛选 */}
              <View style={styles.filterSection}>
                <Text style={styles.filterLabel}>适用场景</Text>
                <View style={styles.filterTags}>
                  {filterOptions.scene.map(value => renderFilterTag('scene', value))}
                </View>
              </View>
              
              {/* 重置按钮 */}
              <TouchableOpacity
                style={styles.resetButton}
                onPress={handleResetFilters}
              >
                <FontAwesome6 name="arrow-rotate-left" size={14} color="#1D2129" />
                <Text style={styles.resetButtonText}>重置筛选</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* 人设列表 */}
        <View style={styles.personaList}>
          {/* 预设人设 */}
          <View style={styles.personaSection}>
            <Text style={styles.sectionTitle}>预设人设</Text>
            <View style={styles.personaCards}>
              {personas.slice(0, 4).map(renderPersonaCard)}
            </View>
          </View>

          {/* 自定义人设 */}
          <View style={styles.personaSection}>
            <Text style={styles.sectionTitle}>我的人设</Text>
            <View style={styles.personaCards}>
              {personas.slice(4).map(renderPersonaCard)}
            </View>
          </View>
        </View>
      </ScrollView>

      {/* 应用范围选择弹窗 */}
      <Modal
        visible={isApplicationModalVisible}
        transparent={true}
        animationType="fade"
        onRequestClose={handleCancelApplication}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>应用人设</Text>
            <Text style={styles.modalDescription}>请选择要应用的范围：</Text>
            
            <View style={styles.applicationOptions}>
              <TouchableOpacity
                style={styles.applicationOption}
                onPress={() => handleApplicationTypeSelect('global')}
              >
                <View style={styles.applicationOptionContent}>
                  <View style={styles.applicationOptionLeft}>
                    <FontAwesome6 name="globe" size={16} color="#165DFF" />
                    <Text style={styles.applicationOptionText}>设为全局默认</Text>
                  </View>
                  {selectedApplicationType === 'global' && (
                    <FontAwesome6 name="check" size={16} color="#165DFF" />
                  )}
                </View>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.applicationOption}
                onPress={() => handleApplicationTypeSelect('contact')}
              >
                <View style={styles.applicationOptionContent}>
                  <View style={styles.applicationOptionLeft}>
                    <FontAwesome6 name="user-group" size={16} color="#165DFF" />
                    <Text style={styles.applicationOptionText}>指定联系人</Text>
                  </View>
                  <FontAwesome6 name="chevron-right" size={14} color="#86909C" />
                </View>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.applicationOption}
                onPress={() => handleApplicationTypeSelect('scene')}
              >
                <View style={styles.applicationOptionContent}>
                  <View style={styles.applicationOptionLeft}>
                    <FontAwesome6 name="masks-theater" size={16} color="#165DFF" />
                    <Text style={styles.applicationOptionText}>指定场景</Text>
                  </View>
                  <FontAwesome6 name="chevron-right" size={14} color="#86909C" />
                </View>
              </TouchableOpacity>
            </View>
            
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalCancelButton}
                onPress={handleCancelApplication}
              >
                <Text style={styles.modalCancelButtonText}>取消</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.modalConfirmButton}
                onPress={handleConfirmApplication}
              >
                <Text style={styles.modalConfirmButtonText}>确认</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Toast 提示 */}
      {isToastVisible && (
        <View style={styles.toast}>
          <Text style={styles.toastText}>{toastMessage}</Text>
        </View>
      )}
    </SafeAreaView>
  );
};

export default PersonaLibraryScreen;

