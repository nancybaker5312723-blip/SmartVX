

import React from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { FontAwesome6 } from '@expo/vector-icons';
import styles from './styles';

const SettingsScreen = () => {
  const router = useRouter();

  const handlePrivacySecurityPress = () => {
    router.push('/p-privacy_security');
  };

  const handleLabPress = () => {
    router.push('/p-lab');
  };

  const handleAboutPress = () => {
    router.push('/p-about');
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* 顶部导航 */}
        <View style={styles.header}>
          <Text style={styles.pageTitle}>设置</Text>
        </View>

        {/* 设置列表 */}
        <View style={styles.settingsList}>
          {/* 隐私与安全 */}
          <TouchableOpacity 
            style={styles.settingItem} 
            onPress={handlePrivacySecurityPress}
            activeOpacity={0.7}
          >
            <View style={styles.settingItemContent}>
              <View style={styles.settingItemLeft}>
                <View style={[styles.iconContainer, styles.primaryIconContainer]}>
                  <FontAwesome6 name="shield-halved" size={16} color="#165DFF" />
                </View>
                <View style={styles.settingItemTextContainer}>
                  <Text style={styles.settingItemTitle}>隐私与安全</Text>
                  <Text style={styles.settingItemSubtitle}>管理数据隐私和安全设置</Text>
                </View>
              </View>
              <FontAwesome6 name="chevron-right" size={14} color="#9CA3AF" />
            </View>
          </TouchableOpacity>

          {/* 实验室（Beta） */}
          <TouchableOpacity 
            style={styles.settingItem} 
            onPress={handleLabPress}
            activeOpacity={0.7}
          >
            <View style={styles.settingItemContent}>
              <View style={styles.settingItemLeft}>
                <View style={[styles.iconContainer, styles.secondaryIconContainer]}>
                  <FontAwesome6 name="flask" size={16} color="#4080FF" />
                </View>
                <View style={styles.settingItemTextContainer}>
                  <Text style={styles.settingItemTitle}>实验室（Beta）</Text>
                  <Text style={styles.settingItemSubtitle}>体验实验性高级功能</Text>
                </View>
              </View>
              <View style={styles.settingItemRight}>
                <View style={styles.betaBadge}>
                  <Text style={styles.betaBadgeText}>Beta</Text>
                </View>
                <FontAwesome6 name="chevron-right" size={14} color="#9CA3AF" />
              </View>
            </View>
          </TouchableOpacity>

          {/* 关于 */}
          <TouchableOpacity 
            style={styles.settingItem} 
            onPress={handleAboutPress}
            activeOpacity={0.7}
          >
            <View style={styles.settingItemContent}>
              <View style={styles.settingItemLeft}>
                <View style={[styles.iconContainer, styles.grayIconContainer]}>
                  <FontAwesome6 name="circle-info" size={16} color="#6B7280" />
                </View>
                <View style={styles.settingItemTextContainer}>
                  <Text style={styles.settingItemTitle}>关于</Text>
                  <Text style={styles.settingItemSubtitle}>版本信息和法律条款</Text>
                </View>
              </View>
              <FontAwesome6 name="chevron-right" size={14} color="#9CA3AF" />
            </View>
          </TouchableOpacity>
        </View>

        {/* 版本信息 */}
        <View style={styles.versionInfo}>
          <Text style={styles.versionText}>秘语 v1.0.0</Text>
          <Text style={styles.copyrightText}>© 2024 SmartWX. All rights reserved.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default SettingsScreen;

