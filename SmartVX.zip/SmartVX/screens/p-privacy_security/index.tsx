

import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Switch, Modal, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { FontAwesome6 } from '@expo/vector-icons';
import styles from './styles';

type SendConfirmOption = 'always' | 'whitelist';

const PrivacySecurityScreen = () => {
  const router = useRouter();
  
  // 各种开关状态
  const [isLocalMemoryEnabled, setIsLocalMemoryEnabled] = useState(true);
  const [isCloudInferenceEnabled, setIsCloudInferenceEnabled] = useState(true);
  const [isWifiOnlyEnabled, setIsWifiOnlyEnabled] = useState(true);
  const [isBoundaryAlertEnabled, setIsBoundaryAlertEnabled] = useState(true);
  const [isFingerprintLockEnabled, setIsFingerprintLockEnabled] = useState(false);
  
  // 弹窗显示状态
  const [isSendConfirmModalVisible, setIsSendConfirmModalVisible] = useState(false);
  const [isClearMemoryModalVisible, setIsClearMemoryModalVisible] = useState(false);
  const [isScreenReadingModalVisible, setIsScreenReadingModalVisible] = useState(false);
  
  // 发送确认选项
  const [selectedSendConfirmOption, setSelectedSendConfirmOption] = useState<SendConfirmOption>('always');
  
  // Toast状态
  const [isToastVisible, setIsToastVisible] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  const handleBackPress = () => {
    if (router.canGoBack()) {
      router.back();
    }
  };

  const showToast = (message: string) => {
    setToastMessage(message);
    setIsToastVisible(true);
    setTimeout(() => {
      setIsToastVisible(false);
    }, 3000);
  };

  const handleLocalMemoryToggle = (value: boolean) => {
    setIsLocalMemoryEnabled(value);
    showToast(value ? '本地记忆已开启' : '本地记忆已关闭');
  };

  const handleCloudInferenceToggle = (value: boolean) => {
    setIsCloudInferenceEnabled(value);
    showToast(value ? '云端推理已开启' : '云端推理已关闭');
  };

  const handleWifiOnlyToggle = (value: boolean) => {
    setIsWifiOnlyEnabled(value);
    showToast(value ? '仅Wi-Fi使用云端已开启' : '仅Wi-Fi使用云端已关闭');
  };

  const handleBoundaryAlertToggle = (value: boolean) => {
    setIsBoundaryAlertEnabled(value);
    showToast(value ? '越界提醒已开启' : '越界提醒已关闭');
  };

  const handleFingerprintLockToggle = (value: boolean) => {
    setIsFingerprintLockEnabled(value);
    showToast(value ? '指纹解锁已开启' : '指纹解锁已关闭');
  };

  const handleClearAllMemoryPress = () => {
    setIsClearMemoryModalVisible(true);
  };

  const handleExportBackupPress = () => {
    showToast('备份导出中...');
    setTimeout(() => {
      showToast('备份导出完成');
    }, 2000);
  };

  const handleSendConfirmPress = () => {
    setIsSendConfirmModalVisible(true);
  };

  const handleScreenReadingPress = () => {
    setIsScreenReadingModalVisible(true);
  };

  const handleSendConfirmOptionSelect = (option: SendConfirmOption) => {
    setSelectedSendConfirmOption(option);
  };

  const handleSendConfirmConfirm = () => {
    const optionText = selectedSendConfirmOption === 'always' ? '一律二次确认' : '按对象白名单';
    setIsSendConfirmModalVisible(false);
    showToast(`发送确认已设置为：${optionText}`);
  };

  const handleClearMemoryConfirm = () => {
    setIsClearMemoryModalVisible(false);
    showToast('正在清空记忆...');
    setTimeout(() => {
      showToast('全部记忆已清空');
    }, 2000);
  };

  const getSendConfirmOptionText = () => {
    return selectedSendConfirmOption === 'always' ? '一律二次确认' : '按对象白名单';
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* 顶部导航 */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={handleBackPress}>
          <FontAwesome6 name="chevron-left" size={16} color="#374151" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>隐私与安全</Text>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <View style={styles.content}>
          {/* 数据管理 */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>数据管理</Text>
            
            <View style={styles.settingItem}>
              <View style={styles.settingItemContent}>
                <Text style={styles.settingItemTitle}>本地记忆</Text>
                <Text style={styles.settingItemDescription}>保存聊天历史以提供更好的建议</Text>
              </View>
              <Switch
                value={isLocalMemoryEnabled}
                onValueChange={handleLocalMemoryToggle}
                trackColor={{ false: '#e5e5e5', true: '#165DFF' }}
                thumbColor="#ffffff"
              />
            </View>
            
            <View style={styles.divider} />
            
            <TouchableOpacity style={styles.actionButton} onPress={handleClearAllMemoryPress}>
              <View style={styles.actionButtonContent}>
                <View style={styles.actionButtonLeft}>
                  <FontAwesome6 name="trash-can" size={16} color="#ef4444" />
                  <Text style={styles.actionButtonTitle}>清空全部记忆</Text>
                </View>
                <FontAwesome6 name="chevron-right" size={14} color="#9ca3af" />
              </View>
              <Text style={styles.actionButtonDescription}>删除所有本地存储的聊天记录和记忆</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.actionButton} onPress={handleExportBackupPress}>
              <View style={styles.actionButtonContent}>
                <View style={styles.actionButtonLeft}>
                  <FontAwesome6 name="download" size={16} color="#165DFF" />
                  <Text style={styles.actionButtonTitle}>导出备份</Text>
                </View>
                <FontAwesome6 name="chevron-right" size={14} color="#9ca3af" />
              </View>
              <Text style={styles.actionButtonDescription}>将本地数据导出为备份文件</Text>
            </TouchableOpacity>
          </View>

          {/* 云端设置 */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>云端设置</Text>
            
            <View style={styles.settingItem}>
              <View style={styles.settingItemContent}>
                <Text style={styles.settingItemTitle}>云端推理</Text>
                <Text style={styles.settingItemDescription}>使用云端AI模型进行推理</Text>
              </View>
              <Switch
                value={isCloudInferenceEnabled}
                onValueChange={handleCloudInferenceToggle}
                trackColor={{ false: '#e5e5e5', true: '#165DFF' }}
                thumbColor="#ffffff"
              />
            </View>
            
            <View style={styles.settingItem}>
              <View style={styles.settingItemContent}>
                <Text style={styles.settingItemTitle}>仅在Wi-Fi使用云端</Text>
                <Text style={styles.settingItemDescription}>避免使用移动数据进行云端推理</Text>
              </View>
              <Switch
                value={isWifiOnlyEnabled}
                onValueChange={handleWifiOnlyToggle}
                trackColor={{ false: '#e5e5e5', true: '#165DFF' }}
                thumbColor="#ffffff"
              />
            </View>
          </View>

          {/* 屏幕读取说明 */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>屏幕读取</Text>
            
            <TouchableOpacity style={styles.infoCard} onPress={handleScreenReadingPress}>
              <View style={styles.infoCardContent}>
                <View style={styles.infoCardText}>
                  <Text style={styles.infoCardTitle}>屏幕读取(OCR)仅用于解析</Text>
                  <Text style={styles.infoCardDescription}>
                    我们使用屏幕读取技术来识别聊天内容，以便提供智能回复建议。原始截图不会被存储，仅临时用于文本识别。
                  </Text>
                </View>
                <FontAwesome6 name="circle-info" size={16} color="#165DFF" />
              </View>
            </TouchableOpacity>
          </View>

          {/* 发送确认 */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>发送确认</Text>
            
            <TouchableOpacity style={styles.settingItemClickable} onPress={handleSendConfirmPress}>
              <View style={styles.settingItemContent}>
                <Text style={styles.settingItemTitle}>发送前确认</Text>
                <Text style={styles.settingItemDescription}>控制AI建议的发送确认方式</Text>
                <Text style={styles.settingItemCurrentValue}>当前：{getSendConfirmOptionText()}</Text>
              </View>
              <FontAwesome6 name="chevron-right" size={14} color="#9ca3af" />
            </TouchableOpacity>
          </View>

          {/* 越界提醒 */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>越界提醒</Text>
            
            <View style={styles.settingItem}>
              <View style={styles.settingItemContent}>
                <Text style={styles.settingItemTitle}>越界提醒</Text>
                <Text style={styles.settingItemDescription}>包含敏感词过滤、尊重守则、未成年保护</Text>
              </View>
              <Switch
                value={isBoundaryAlertEnabled}
                onValueChange={handleBoundaryAlertToggle}
                trackColor={{ false: '#e5e5e5', true: '#165DFF' }}
                thumbColor="#ffffff"
              />
            </View>
          </View>

          {/* 安全保护 */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>安全保护</Text>
            
            <View style={styles.settingItem}>
              <View style={styles.settingItemContent}>
                <Text style={styles.settingItemTitle}>本地数据库加密</Text>
                <Text style={styles.settingItemDescription}>您的数据已加密存储</Text>
              </View>
              <View style={styles.statusIndicator}>
                <View style={styles.statusDot} />
                <Text style={styles.statusText}>已启用</Text>
              </View>
            </View>
            
            <View style={styles.settingItem}>
              <View style={styles.settingItemContent}>
                <Text style={styles.settingItemTitle}>指纹解锁</Text>
                <Text style={styles.settingItemDescription}>使用指纹或面容ID保护应用</Text>
              </View>
              <Switch
                value={isFingerprintLockEnabled}
                onValueChange={handleFingerprintLockToggle}
                trackColor={{ false: '#e5e5e5', true: '#165DFF' }}
                thumbColor="#ffffff"
              />
            </View>
          </View>
        </View>
      </ScrollView>

      {/* 发送确认选项弹窗 */}
      <Modal
        visible={isSendConfirmModalVisible}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setIsSendConfirmModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>发送前确认</Text>
            
            <View style={styles.optionsContainer}>
              <TouchableOpacity
                style={[
                  styles.optionItem,
                  selectedSendConfirmOption === 'always' && styles.optionItemSelected
                ]}
                onPress={() => handleSendConfirmOptionSelect('always')}
              >
                <View style={styles.optionItemContent}>
                  <View>
                    <Text style={styles.optionItemTitle}>一律二次确认</Text>
                    <Text style={styles.optionItemDescription}>每次发送AI建议前都需要确认</Text>
                  </View>
                  <FontAwesome6
                    name="check"
                    size={16}
                    color={selectedSendConfirmOption === 'always' ? '#165DFF' : '#d1d5db'}
                  />
                </View>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.optionItem,
                  selectedSendConfirmOption === 'whitelist' && styles.optionItemSelected
                ]}
                onPress={() => handleSendConfirmOptionSelect('whitelist')}
              >
                <View style={styles.optionItemContent}>
                  <View>
                    <Text style={styles.optionItemTitle}>按对象白名单</Text>
                    <Text style={styles.optionItemDescription}>仅对非白名单联系人进行确认</Text>
                  </View>
                  <FontAwesome6
                    name="check"
                    size={16}
                    color={selectedSendConfirmOption === 'whitelist' ? '#165DFF' : '#d1d5db'}
                  />
                </View>
              </TouchableOpacity>
            </View>
            
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={styles.modalCancelButton}
                onPress={() => setIsSendConfirmModalVisible(false)}
              >
                <Text style={styles.modalCancelButtonText}>取消</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.modalConfirmButton}
                onPress={handleSendConfirmConfirm}
              >
                <Text style={styles.modalConfirmButtonText}>确定</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* 清空记忆确认弹窗 */}
      <Modal
        visible={isClearMemoryModalVisible}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setIsClearMemoryModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.warningContainer}>
              <View style={styles.warningIcon}>
                <FontAwesome6 name="triangle-exclamation" size={24} color="#ef4444" />
              </View>
              <Text style={styles.warningTitle}>确认清空全部记忆？</Text>
              <Text style={styles.warningDescription}>
                此操作不可撤销，将删除所有本地存储的聊天记录和记忆数据。
              </Text>
            </View>
            
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={styles.modalCancelButton}
                onPress={() => setIsClearMemoryModalVisible(false)}
              >
                <Text style={styles.modalCancelButtonText}>取消</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.modalDangerButton}
                onPress={handleClearMemoryConfirm}
              >
                <Text style={styles.modalDangerButtonText}>清空</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* 屏幕读取详细说明弹窗 */}
      <Modal
        visible={isScreenReadingModalVisible}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setIsScreenReadingModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContentLarge}>
            <Text style={styles.modalTitle}>屏幕读取说明</Text>
            
            <ScrollView style={styles.modalScrollContent} showsVerticalScrollIndicator={false}>
              <View style={styles.infoSection}>
                <Text style={styles.infoSectionTitle}>什么是屏幕读取？</Text>
                <Text style={styles.infoSectionText}>
                  屏幕读取（OCR）是一种技术，用于识别屏幕上显示的文字内容。我们使用这项技术来分析您当前的聊天界面，以便提供相关的AI回复建议。
                </Text>
              </View>
              
              <View style={styles.infoSection}>
                <Text style={styles.infoSectionTitle}>我们如何使用这些数据？</Text>
                <View style={styles.bulletPoint}>
                  <Text style={styles.bulletPointText}>• 仅用于生成AI回复建议</Text>
                </View>
                <View style={styles.bulletPoint}>
                  <Text style={styles.bulletPointText}>• 不会存储原始截图或完整聊天记录</Text>
                </View>
                <View style={styles.bulletPoint}>
                  <Text style={styles.bulletPointText}>• 处理完成后立即删除临时数据</Text>
                </View>
                <View style={styles.bulletPoint}>
                  <Text style={styles.bulletPointText}>• 严格遵循隐私保护原则</Text>
                </View>
              </View>
              
              <View style={styles.infoSection}>
                <Text style={styles.infoSectionTitle}>您的隐私保护</Text>
                <Text style={styles.infoSectionText}>
                  我们承诺保护您的隐私安全。屏幕读取功能可以随时关闭，您可以完全控制数据的使用方式。
                </Text>
              </View>
            </ScrollView>
            
            <TouchableOpacity
              style={styles.modalConfirmButton}
              onPress={() => setIsScreenReadingModalVisible(false)}
            >
              <Text style={styles.modalConfirmButtonText}>我明白了</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* 成功提示 */}
      {isToastVisible && (
        <View style={styles.toast}>
          <FontAwesome6 name="circle-check" size={16} color="#ffffff" />
          <Text style={styles.toastText}>{toastMessage}</Text>
        </View>
      )}
    </SafeAreaView>
  );
};

export default PrivacySecurityScreen;

