

import { StyleSheet, Platform } from 'react-native';

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F3F5',
  },
  
  // 顶部导航
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E6EB',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1D2129',
  },
  
  // 滚动视图
  scrollView: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 24,
    paddingVertical: 24,
    gap: 24,
  },
  
  // 分组样式
  section: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 20,
    borderWidth: 1,
    borderColor: '#E5E6EB',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 2,
      },
      android: {
        elevation: 1,
      },
    }),
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1D2129',
    marginBottom: 16,
  },
  
  // 设置项样式
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  settingItemClickable: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  settingItemContent: {
    flex: 1,
    marginRight: 16,
  },
  settingItemTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
    marginBottom: 4,
  },
  settingItemDescription: {
    fontSize: 12,
    color: '#86909C',
    marginBottom: 4,
  },
  settingItemCurrentValue: {
    fontSize: 12,
    color: '#165DFF',
  },
  
  // 分割线
  divider: {
    height: 1,
    backgroundColor: '#E5E6EB',
    marginVertical: 16,
  },
  
  // 操作按钮
  actionButton: {
    backgroundColor: '#F7F8FA',
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
  },
  actionButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  actionButtonLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  actionButtonTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
    marginLeft: 12,
  },
  actionButtonDescription: {
    fontSize: 12,
    color: '#86909C',
    marginLeft: 28,
  },
  
  // 信息卡片
  infoCard: {
    backgroundColor: 'rgba(22, 93, 255, 0.05)',
    borderRadius: 8,
    padding: 16,
  },
  infoCardContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
  },
  infoCardText: {
    flex: 1,
    marginRight: 12,
  },
  infoCardTitle: {
    fontSize: 14,
    color: '#1D2129',
    marginBottom: 8,
  },
  infoCardDescription: {
    fontSize: 12,
    color: '#4E5969',
    lineHeight: 18,
  },
  
  // 状态指示器
  statusIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10b981',
    marginRight: 8,
  },
  statusText: {
    fontSize: 12,
    color: '#10b981',
    fontWeight: '500',
  },
  
  // 弹窗样式
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 24,
    width: '100%',
    maxWidth: 400,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 20 },
        shadowOpacity: 0.25,
        shadowRadius: 25,
      },
      android: {
        elevation: 20,
      },
    }),
  },
  modalContentLarge: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 24,
    width: '100%',
    maxWidth: 400,
    maxHeight: '80%',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 20 },
        shadowOpacity: 0.25,
        shadowRadius: 25,
      },
      android: {
        elevation: 20,
      },
    }),
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1D2129',
    marginBottom: 16,
    textAlign: 'center',
  },
  
  // 选项容器
  optionsContainer: {
    marginBottom: 24,
    gap: 8,
  },
  optionItem: {
    padding: 12,
    borderRadius: 8,
    backgroundColor: '#ffffff',
  },
  optionItemSelected: {
    backgroundColor: 'rgba(22, 93, 255, 0.1)',
  },
  optionItemContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  optionItemTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
    marginBottom: 4,
  },
  optionItemDescription: {
    fontSize: 12,
    color: '#86909C',
  },
  
  // 警告容器
  warningContainer: {
    alignItems: 'center',
    marginBottom: 24,
  },
  warningIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#fef2f2',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  warningTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1D2129',
    marginBottom: 8,
    textAlign: 'center',
  },
  warningDescription: {
    fontSize: 14,
    color: '#4E5969',
    textAlign: 'center',
    lineHeight: 20,
  },
  
  // 弹窗按钮
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  modalCancelButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    backgroundColor: '#F7F8FA',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalCancelButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#4E5969',
  },
  modalConfirmButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    backgroundColor: '#165DFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalConfirmButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#ffffff',
  },
  modalDangerButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    backgroundColor: '#ef4444',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalDangerButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#ffffff',
  },
  
  // 弹窗滚动内容
  modalScrollContent: {
    maxHeight: 300,
    marginBottom: 24,
  },
  infoSection: {
    marginBottom: 24,
  },
  infoSectionTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
    marginBottom: 8,
  },
  infoSectionText: {
    fontSize: 14,
    color: '#4E5969',
    lineHeight: 20,
  },
  bulletPoint: {
    marginBottom: 4,
  },
  bulletPointText: {
    fontSize: 14,
    color: '#4E5969',
    lineHeight: 20,
  },
  
  // Toast样式
  toast: {
    position: 'absolute',
    top: 80,
    left: '50%',
    transform: [{ translateX: -100 }],
    backgroundColor: '#10b981',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
    zIndex: 1000,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
      },
      android: {
        elevation: 8,
      },
    }),
  },
  toastText: {
    fontSize: 14,
    color: '#ffffff',
    marginLeft: 8,
    fontWeight: '500',
  },
});

