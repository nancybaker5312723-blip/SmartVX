

import { StyleSheet, Platform } from 'react-native';

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F3F5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E6EB',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    flex: 1,
    fontSize: 18,
    fontWeight: '600',
    color: '#1D2129',
    textAlign: 'center',
  },
  headerPlaceholder: {
    width: 40,
  },
  contactInfoContainer: {
    paddingHorizontal: 24,
    paddingTop: 24,
  },
  minimalCard: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E5E6EB',
    borderRadius: 8,
    padding: 24,
  },
  contactInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  contactAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    marginRight: 16,
  },
  contactDetails: {
    flex: 1,
  },
  contactName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1D2129',
    marginBottom: 4,
  },
  contactStats: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  adoptionRateContainer: {
    alignItems: 'center',
    marginRight: 16,
  },
  adoptionRateCircle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#E5E6EB',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  adoptionRateInner: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  adoptionRateText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#165DFF',
  },
  adoptionRateLabel: {
    fontSize: 10,
    color: '#86909C',
  },
  contactMeta: {
    flex: 1,
  },
  contactMetaText: {
    fontSize: 14,
    color: '#4E5969',
    marginBottom: 2,
  },
  tabSection: {
    paddingHorizontal: 24,
    paddingTop: 24,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#F7F8FA',
    borderRadius: 8,
    padding: 4,
  },
  tab: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 6,
    alignItems: 'center',
  },
  tabActive: {
    backgroundColor: '#165DFF',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#86909C',
  },
  tabTextActive: {
    color: '#FFFFFF',
  },
  scrollView: {
    flex: 1,
  },
  tabContentContainer: {
    paddingHorizontal: 24,
    paddingTop: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1D2129',
    marginBottom: 16,
  },
  suggestionsList: {
    gap: 16,
  },
  suggestionItem: {
    padding: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E5E6EB',
    backgroundColor: '#FFFFFF',
  },
  suggestionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  suggestionTime: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusAdopted: {
    backgroundColor: '#D1FAE5',
  },
  statusRewritten: {
    backgroundColor: '#FEF3C7',
  },
  statusRejected: {
    backgroundColor: '#F3F4F6',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '500',
  },
  userInputText: {
    fontSize: 14,
    color: '#4E5969',
    marginBottom: 8,
  },
  suggestionText: {
    fontSize: 14,
    color: '#165DFF',
    marginBottom: 8,
  },
  rewrittenText: {
    fontSize: 14,
    color: '#86909C',
  },
  memoryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  editButton: {
    fontSize: 14,
    color: '#165DFF',
    fontWeight: '500',
  },
  tagsContainer: {
    gap: 16,
  },
  tagCategory: {
    gap: 8,
  },
  categoryTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#4E5969',
  },
  tagsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  memoryTag: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: '#F7F8FA',
    borderWidth: 1,
    borderColor: '#E5E6EB',
  },
  memoryTagEditMode: {
    backgroundColor: '#FFFFFF',
    borderColor: '#165DFF',
  },
  tagText: {
    fontSize: 14,
    color: '#1D2129',
  },
  deleteTagButton: {
    marginLeft: 4,
    padding: 2,
  },
  addTagSection: {
    marginTop: 24,
  },
  addTagRow: {
    gap: 12,
  },
  tagTypeContainer: {
    gap: 8,
  },
  tagTypeLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
  },
  tagTypeOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  tagTypeOption: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: '#F7F8FA',
    borderWidth: 1,
    borderColor: '#E5E6EB',
  },
  tagTypeOptionActive: {
    backgroundColor: '#165DFF',
    borderColor: '#165DFF',
  },
  tagTypeOptionText: {
    fontSize: 12,
    color: '#4E5969',
  },
  tagTypeOptionTextActive: {
    color: '#FFFFFF',
  },
  tagValueInput: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E5E6EB',
    borderRadius: 4,
    paddingHorizontal: 12,
    paddingVertical: 8,
    fontSize: 14,
    color: '#333333',
  },
  addTagButton: {
    backgroundColor: '#165DFF',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 4,
    alignSelf: 'flex-start',
  },
  addTagButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  currentPersona: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#F7F8FA',
    borderRadius: 8,
    marginBottom: 16,
  },
  personaIcon: {
    width: 32,
    height: 32,
    backgroundColor: '#E5E6EB',
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  personaInfo: {
    flex: 1,
  },
  personaName: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1D2129',
    marginBottom: 2,
  },
  personaDescription: {
    fontSize: 14,
    color: '#4E5969',
  },
  personaBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    backgroundColor: 'rgba(22, 93, 255, 0.1)',
    borderRadius: 12,
  },
  personaBadgeText: {
    fontSize: 12,
    color: '#165DFF',
  },
  changePersonaButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    backgroundColor: '#F7F8FA',
    borderRadius: 8,
    gap: 8,
  },
  changePersonaButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1D2129',
  },
  privacyActions: {
    gap: 16,
  },
  privacyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    backgroundColor: '#F7F8FA',
    borderRadius: 8,
    gap: 8,
  },
  privacyButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1D2129',
  },
  resetButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#FECACA',
    borderRadius: 8,
    gap: 8,
  },
  resetButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#DC2626',
  },
  privacyNotice: {
    marginTop: 24,
    padding: 16,
    backgroundColor: '#F7F8FA',
    borderRadius: 8,
  },
  privacyNoticeTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
    marginBottom: 8,
  },
  privacyNoticeText: {
    fontSize: 12,
    color: '#4E5969',
    lineHeight: 18,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 24,
    width: '100%',
    maxWidth: 400,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 20 },
        shadowOpacity: 0.25,
        shadowRadius: 25,
      },
      android: {
        elevation: 20,
      },
    }),
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1D2129',
    marginBottom: 16,
  },
  modalMessage: {
    fontSize: 14,
    color: '#4E5969',
    marginBottom: 24,
    lineHeight: 20,
  },
  personaOptions: {
    gap: 12,
    marginBottom: 24,
  },
  personaOption: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E5E6EB',
    backgroundColor: '#FFFFFF',
  },
  personaOptionIcon: {
    width: 24,
    height: 24,
    backgroundColor: '#E5E6EB',
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  personaOptionInfo: {
    flex: 1,
  },
  personaOptionName: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1D2129',
    marginBottom: 2,
  },
  personaOptionDescription: {
    fontSize: 14,
    color: '#4E5969',
  },
  radioButton: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#E5E6EB',
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioButtonSelected: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#165DFF',
  },
  modalActions: {
    flexDirection: 'row',
    gap: 12,
  },
  modalCancelButton: {
    flex: 1,
    paddingVertical: 8,
    backgroundColor: '#F7F8FA',
    borderRadius: 8,
    alignItems: 'center',
  },
  modalCancelButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1D2129',
  },
  modalConfirmButton: {
    flex: 1,
    paddingVertical: 8,
    backgroundColor: '#165DFF',
    borderRadius: 8,
    alignItems: 'center',
  },
  modalConfirmButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#FFFFFF',
  },
  modalDangerButton: {
    flex: 1,
    paddingVertical: 8,
    backgroundColor: '#EF4444',
    borderRadius: 8,
    alignItems: 'center',
  },
  modalDangerButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#FFFFFF',
  },
  bottomSpacing: {
    height: 32,
  },
});

