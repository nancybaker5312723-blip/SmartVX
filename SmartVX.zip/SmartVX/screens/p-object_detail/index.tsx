

import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image, TextInput, Modal, Alert, } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { FontAwesome6 } from '@expo/vector-icons';
import styles from './styles';

interface ObjectData {
  name: string;
  avatar: string;
  adoptionRate: number;
  lastChatTime: string;
  interactionCount: number;
}

interface SuggestionItem {
  id: string;
  time: string;
  status: 'adopted' | 'rewritten' | 'rejected';
  userInput: string;
  suggestion: string;
  rewritten?: string;
}

interface MemoryTag {
  id: string;
  type: 'gender' | 'age' | 'hobby' | 'avoid' | 'topic' | 'important-date';
  value: string;
}

interface PersonaOption {
  id: string;
  name: string;
  description: string;
  icon: string;
}

type TabType = 'conversation' | 'memory' | 'persona' | 'privacy';

const ObjectDetailScreen: React.FC = () => {
  const router = useRouter();
  const params = useLocalSearchParams();
  
  const [activeTab, setActiveTab] = useState<TabType>('conversation');
  const [isEditMode, setIsEditMode] = useState(false);
  const [isPersonaModalVisible, setIsPersonaModalVisible] = useState(false);
  const [isConfirmModalVisible, setIsConfirmModalVisible] = useState(false);
  const [confirmModalConfig, setConfirmModalConfig] = useState({
    title: '',
    message: '',
    onConfirm: () => {},
  });
  const [selectedPersona, setSelectedPersona] = useState('warm-student');
  const [tagType, setTagType] = useState('');
  const [tagValue, setTagValue] = useState('');
  
  const [objectData, setObjectData] = useState<ObjectData>({
    name: '小雨',
    avatar: 'https://s.coze.cn/image/t4pKbFR-1IM/',
    adoptionRate: 85,
    lastChatTime: '2分钟前',
    interactionCount: 42,
  });

  const [suggestions, setSuggestions] = useState<SuggestionItem[]>([
    {
      id: '1',
      time: '2分钟前',
      status: 'adopted',
      userInput: '周末想去看电影，有什么推荐吗？',
      suggestion: '那太棒了！要不要一起去看最近上映的《流浪地球3》？听说口碑很不错。',
    },
    {
      id: '2',
      time: '1小时前',
      status: 'rewritten',
      userInput: '今天工作好累啊',
      suggestion: '辛苦了！要不要一起吃个饭放松一下？',
      rewritten: '是啊，好想早点下班休息',
    },
    {
      id: '3',
      time: '昨天',
      status: 'rejected',
      userInput: '这个方案怎么样？',
      suggestion: '看起来很不错，我觉得可以试试',
    },
  ]);

  const [memoryTags, setMemoryTags] = useState<MemoryTag[]>([
    { id: '1', type: 'gender', value: '女性' },
    { id: '2', type: 'age', value: '25岁' },
    { id: '3', type: 'hobby', value: '看电影' },
    { id: '4', type: 'hobby', value: '旅行' },
    { id: '5', type: 'hobby', value: '美食' },
    { id: '6', type: 'avoid', value: '加班' },
    { id: '7', type: 'avoid', value: '前任' },
    { id: '8', type: 'topic', value: '电影推荐' },
    { id: '9', type: 'topic', value: '旅行攻略' },
    { id: '10', type: 'topic', value: '美食探店' },
    { id: '11', type: 'important-date', value: '生日：3月15日' },
  ]);

  const personaOptions: PersonaOption[] = [
    {
      id: 'warm-student',
      name: '暖心同学',
      description: '温柔体贴，善解人意',
      icon: 'heart',
    },
    {
      id: 'stable-colleague',
      name: '稳重同事',
      description: '专业严谨，条理清晰',
      icon: 'briefcase',
    },
    {
      id: 'energetic-friend',
      name: '元气伙伴',
      description: '活泼开朗，充满活力',
      icon: 'sun',
    },
  ];

  useEffect(() => {
    if (params.objectId) {
      loadObjectDetails(params.objectId as string);
    }
  }, [params.objectId]);

  const loadObjectDetails = (objectId: string) => {
    // 模拟加载对象详情
    const mockObjects: Record<string, ObjectData> = {
      object1: {
        name: '小雨',
        avatar: 'https://s.coze.cn/image/gVbgztljLQM/',
        adoptionRate: 85,
        lastChatTime: '2分钟前',
        interactionCount: 42,
      },
      object2: {
        name: '张总',
        avatar: 'https://s.coze.cn/image/xAUZIcvYH9k/',
        adoptionRate: 72,
        lastChatTime: '1小时前',
        interactionCount: 28,
      },
      object3: {
        name: '小美',
        avatar: 'https://s.coze.cn/image/ZhW1XZ2d49U/',
        adoptionRate: 91,
        lastChatTime: '昨天',
        interactionCount: 56,
      },
    };

    const object = mockObjects[objectId];
    if (object) {
      setObjectData(object);
    }
  };

  const handleBackPress = () => {
    if (router.canGoBack()) {
      router.back();
    } else {
      router.push('/p-home');
    }
  };

  const handleTabPress = (tab: TabType) => {
    setActiveTab(tab);
  };

  const handleEditTagsPress = () => {
    setIsEditMode(!isEditMode);
    if (isEditMode) {
      setTagType('');
      setTagValue('');
    }
  };

  const handleDeleteTag = (tagId: string) => {
    setMemoryTags(prevTags => prevTags.filter(tag => tag.id !== tagId));
  };

  const handleAddTag = () => {
    if (!tagType || !tagValue.trim()) {
      Alert.alert('提示', '请选择标签类型并输入标签内容');
      return;
    }

    const newTag: MemoryTag = {
      id: Date.now().toString(),
      type: tagType as any,
      value: tagValue.trim(),
    };

    setMemoryTags(prevTags => [...prevTags, newTag]);
    setTagValue('');
  };

  const handleChangePersona = () => {
    setIsPersonaModalVisible(true);
  };

  const handleConfirmPersona = () => {
    setIsPersonaModalVisible(false);
    Alert.alert('成功', '人设已更新');
  };

  const showConfirmModal = (title: string, message: string, onConfirm: () => void) => {
    setConfirmModalConfig({ title, message, onConfirm });
    setIsConfirmModalVisible(true);
  };

  const handleConfirmAction = () => {
    setIsConfirmModalVisible(false);
    confirmModalConfig.onConfirm();
  };

  const handleClearMemory = () => {
    showConfirmModal(
      '清理记忆',
      '确定要清理与此联系人相关的所有本地记忆吗？此操作不可恢复。',
      () => {
        Alert.alert('完成', '记忆清理完成');
      }
    );
  };

  const handleExportChat = () => {
    showConfirmModal(
      '导出聊天记录',
      '确定要导出与此联系人的聊天记录吗？',
      () => {
        Alert.alert('完成', '导出完成');
      }
    );
  };

  const handleResetSettings = () => {
    showConfirmModal(
      '重置设置',
      '确定要重置与此联系人的所有设置吗？包括人设、记忆标签等。',
      () => {
        Alert.alert('完成', '设置已重置');
      }
    );
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'adopted':
        return '已采纳';
      case 'rewritten':
        return '已改写';
      case 'rejected':
        return '已拒绝';
      default:
        return '';
    }
  };

  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'adopted':
        return styles.statusAdopted;
      case 'rewritten':
        return styles.statusRewritten;
      case 'rejected':
        return styles.statusRejected;
      default:
        return styles.statusAdopted;
    }
  };

  const getTagCategory = (type: string) => {
    switch (type) {
      case 'gender':
      case 'age':
        return '基本信息';
      case 'hobby':
        return '喜好';
      case 'avoid':
        return '避雷词';
      case 'topic':
        return '可聊话题';
      case 'important-date':
        return '重要时间';
      default:
        return '其他';
    }
  };

  const getTagCategoryType = (type: string) => {
    switch (type) {
      case 'gender':
      case 'age':
        return 'basic';
      case 'hobby':
        return 'hobby';
      case 'avoid':
        return 'avoid';
      case 'topic':
        return 'topic';
      case 'important-date':
        return 'date';
      default:
        return 'other';
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'conversation':
        return (
          <View style={styles.tabContentContainer}>
            <View style={styles.minimalCard}>
              <Text style={styles.sectionTitle}>最近建议</Text>
              <View style={styles.suggestionsList}>
                {suggestions.map((item) => (
                  <View key={item.id} style={styles.suggestionItem}>
                    <View style={styles.suggestionHeader}>
                      <Text style={styles.suggestionTime}>{item.time}</Text>
                      <View style={[styles.statusBadge, getStatusStyle(item.status)]}>
                        <Text style={styles.statusText}>{getStatusText(item.status)}</Text>
                      </View>
                    </View>
                    <Text style={styles.userInputText}>用户输入：{item.userInput}</Text>
                    <Text style={styles.suggestionText}>建议回复：{item.suggestion}</Text>
                    {item.rewritten && (
                      <Text style={styles.rewrittenText}>用户改写：{item.rewritten}</Text>
                    )}
                  </View>
                ))}
              </View>
            </View>
          </View>
        );

      case 'memory':
        const groupedTags = memoryTags.reduce((groups, tag) => {
          const category = getTagCategoryType(tag.type);
          if (!groups[category]) {
            groups[category] = [];
          }
          groups[category].push(tag);
          return groups;
        }, {} as Record<string, MemoryTag[]>);

        return (
          <View style={styles.tabContentContainer}>
            <View style={styles.minimalCard}>
              <View style={styles.memoryHeader}>
                <Text style={styles.sectionTitle}>记忆标签</Text>
                <TouchableOpacity onPress={handleEditTagsPress}>
                  <Text style={styles.editButton}>
                    <FontAwesome6 name={isEditMode ? 'check' : 'pen'} size={12} />
                    {' '}
                    {isEditMode ? '完成' : '编辑'}
                  </Text>
                </TouchableOpacity>
              </View>

              <View style={styles.tagsContainer}>
                {Object.entries(groupedTags).map(([categoryType, tags]) => {
                  const categoryTitle = getTagCategory(tags[0]?.type || '');
                  return (
                    <View key={categoryType} style={styles.tagCategory}>
                      <Text style={styles.categoryTitle}>{categoryTitle}</Text>
                      <View style={styles.tagsRow}>
                        {tags.map((tag) => (
                          <View
                            key={tag.id}
                            style={[
                              styles.memoryTag,
                              isEditMode && styles.memoryTagEditMode,
                            ]}
                          >
                            <Text style={styles.tagText}>{tag.value}</Text>
                            {isEditMode && (
                              <TouchableOpacity
                                onPress={() => handleDeleteTag(tag.id)}
                                style={styles.deleteTagButton}
                              >
                                <FontAwesome6 name="xmark" size={10} />
                              </TouchableOpacity>
                            )}
                          </View>
                        ))}
                      </View>
                    </View>
                  );
                })}
              </View>

              {isEditMode && (
                <View style={styles.addTagSection}>
                  <View style={styles.addTagRow}>
                    <View style={styles.tagTypeContainer}>
                      <Text style={styles.tagTypeLabel}>标签类型：</Text>
                      <View style={styles.tagTypeOptions}>
                        {['gender', 'hobby', 'avoid', 'topic', 'important-date'].map((type) => (
                          <TouchableOpacity
                            key={type}
                            style={[
                              styles.tagTypeOption,
                              tagType === type && styles.tagTypeOptionActive,
                            ]}
                            onPress={() => setTagType(type)}
                          >
                            <Text
                              style={[
                                styles.tagTypeOptionText,
                                tagType === type && styles.tagTypeOptionTextActive,
                              ]}
                            >
                              {getTagCategory(type)}
                            </Text>
                          </TouchableOpacity>
                        ))}
                      </View>
                    </View>
                    <TextInput
                      style={styles.tagValueInput}
                      placeholder="输入标签内容"
                      value={tagValue}
                      onChangeText={setTagValue}
                    />
                    <TouchableOpacity style={styles.addTagButton} onPress={handleAddTag}>
                      <Text style={styles.addTagButtonText}>添加</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              )}
            </View>
          </View>
        );

      case 'persona':
        const currentPersona = personaOptions.find(p => p.id === selectedPersona);
        return (
          <View style={styles.tabContentContainer}>
            <View style={styles.minimalCard}>
              <Text style={styles.sectionTitle}>当前人设</Text>
              <View style={styles.currentPersona}>
                <View style={styles.personaIcon}>
                  <FontAwesome6 name={currentPersona?.icon || 'heart'} size={16} />
                </View>
                <View style={styles.personaInfo}>
                  <Text style={styles.personaName}>{currentPersona?.name}</Text>
                  <Text style={styles.personaDescription}>{currentPersona?.description}</Text>
                </View>
                <View style={styles.personaBadge}>
                  <Text style={styles.personaBadgeText}>全局默认</Text>
                </View>
              </View>
              <TouchableOpacity style={styles.changePersonaButton} onPress={handleChangePersona}>
                <FontAwesome6 name="arrow-right-arrow-left" size={14} />
                <Text style={styles.changePersonaButtonText}>切换人设</Text>
              </TouchableOpacity>
            </View>
          </View>
        );

      case 'privacy':
        return (
          <View style={styles.tabContentContainer}>
            <View style={styles.minimalCard}>
              <Text style={styles.sectionTitle}>隐私操作</Text>
              <View style={styles.privacyActions}>
                <TouchableOpacity style={styles.privacyButton} onPress={handleClearMemory}>
                  <FontAwesome6 name="trash-can" size={14} />
                  <Text style={styles.privacyButtonText}>仅清此人的本地记忆</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.privacyButton} onPress={handleExportChat}>
                  <FontAwesome6 name="download" size={14} />
                  <Text style={styles.privacyButtonText}>导出聊天记录</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.resetButton} onPress={handleResetSettings}>
                  <FontAwesome6 name="arrow-rotate-left" size={14} />
                  <Text style={styles.resetButtonText}>重置所有设置</Text>
                </TouchableOpacity>
              </View>
              <View style={styles.privacyNotice}>
                <Text style={styles.privacyNoticeTitle}>隐私说明</Text>
                <Text style={styles.privacyNoticeText}>
                  清理记忆将删除与此联系人相关的所有本地存储数据，包括聊天记录、记忆标签等。此操作不可恢复。
                </Text>
              </View>
            </View>
          </View>
        );

      default:
        return null;
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* 顶部导航 */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={handleBackPress}>
          <FontAwesome6 name="arrow-left" size={18} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{objectData.name}</Text>
        <View style={styles.headerPlaceholder} />
      </View>

      {/* 联系人基本信息 */}
      <View style={styles.contactInfoContainer}>
        <View style={styles.minimalCard}>
          <View style={styles.contactInfo}>
            <Image source={{ uri: objectData.avatar }} style={styles.contactAvatar} />
            <View style={styles.contactDetails}>
              <Text style={styles.contactName}>{objectData.name}</Text>
              <View style={styles.contactStats}>
                <View style={styles.adoptionRateContainer}>
                  <View style={styles.adoptionRateCircle}>
                    <View style={styles.adoptionRateInner}>
                      <Text style={styles.adoptionRateText}>{objectData.adoptionRate}%</Text>
                    </View>
                  </View>
                  <Text style={styles.adoptionRateLabel}>采纳率</Text>
                </View>
                <View style={styles.contactMeta}>
                  <Text style={styles.contactMetaText}>最近聊天：{objectData.lastChatTime}</Text>
                  <Text style={styles.contactMetaText}>互动次数：{objectData.interactionCount}次</Text>
                </View>
              </View>
            </View>
          </View>
        </View>
      </View>

      {/* Tab切换 */}
      <View style={styles.tabSection}>
        <View style={styles.tabContainer}>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'conversation' && styles.tabActive]}
            onPress={() => handleTabPress('conversation')}
          >
            <Text
              style={[
                styles.tabText,
                activeTab === 'conversation' && styles.tabTextActive,
              ]}
            >
              会话摘要
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'memory' && styles.tabActive]}
            onPress={() => handleTabPress('memory')}
          >
            <Text
              style={[
                styles.tabText,
                activeTab === 'memory' && styles.tabTextActive,
              ]}
            >
              记忆标签
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'persona' && styles.tabActive]}
            onPress={() => handleTabPress('persona')}
          >
            <Text
              style={[
                styles.tabText,
                activeTab === 'persona' && styles.tabTextActive,
              ]}
            >
              当前人设
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'privacy' && styles.tabActive]}
            onPress={() => handleTabPress('privacy')}
          >
            <Text
              style={[
                styles.tabText,
                activeTab === 'privacy' && styles.tabTextActive,
              ]}
            >
              隐私
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Tab内容 */}
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {renderTabContent()}
        <View style={styles.bottomSpacing} />
      </ScrollView>

      {/* 人设选择弹窗 */}
      <Modal
        visible={isPersonaModalVisible}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setIsPersonaModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>选择人设</Text>
            <View style={styles.personaOptions}>
              {personaOptions.map((option) => (
                <TouchableOpacity
                  key={option.id}
                  style={styles.personaOption}
                  onPress={() => setSelectedPersona(option.id)}
                >
                  <View style={styles.personaOptionIcon}>
                    <FontAwesome6 name={option.icon} size={12} />
                  </View>
                  <View style={styles.personaOptionInfo}>
                    <Text style={styles.personaOptionName}>{option.name}</Text>
                    <Text style={styles.personaOptionDescription}>{option.description}</Text>
                  </View>
                  <View style={styles.radioButton}>
                    {selectedPersona === option.id && (
                      <View style={styles.radioButtonSelected} />
                    )}
                  </View>
                </TouchableOpacity>
              ))}
            </View>
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalCancelButton}
                onPress={() => setIsPersonaModalVisible(false)}
              >
                <Text style={styles.modalCancelButtonText}>取消</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.modalConfirmButton}
                onPress={handleConfirmPersona}
              >
                <Text style={styles.modalConfirmButtonText}>确认</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* 确认弹窗 */}
      <Modal
        visible={isConfirmModalVisible}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setIsConfirmModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>{confirmModalConfig.title}</Text>
            <Text style={styles.modalMessage}>{confirmModalConfig.message}</Text>
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalCancelButton}
                onPress={() => setIsConfirmModalVisible(false)}
              >
                <Text style={styles.modalCancelButtonText}>取消</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.modalDangerButton}
                onPress={handleConfirmAction}
              >
                <Text style={styles.modalDangerButtonText}>确认</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

export default ObjectDetailScreen;

