

import { StyleSheet, Platform } from 'react-native';

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F3F5',
  },
  
  // 顶部导航
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E6EB',
  },
  
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  
  headerTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1D2129',
    marginRight: 12,
  },
  
  betaBadge: {
    backgroundColor: '#FF6B35',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 10,
  },
  
  betaBadgeText: {
    color: '#ffffff',
    fontSize: 10,
    fontWeight: '600',
  },
  
  // 滚动视图
  scrollView: {
    flex: 1,
  },
  
  content: {
    paddingHorizontal: 24,
    paddingVertical: 24,
    gap: 24,
  },
  
  // 通用section样式
  section: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E5E6EB',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 2,
      },
      android: {
        elevation: 1,
      },
    }),
  },
  
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#F2F3F5',
  },
  
  sectionHeaderInfo: {
    flex: 1,
  },
  
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1D2129',
    marginBottom: 4,
  },
  
  sectionDescription: {
    fontSize: 14,
    color: '#4E5969',
  },
  
  sectionContent: {
    padding: 20,
    gap: 16,
  },
  
  disabledSection: {
    opacity: 0.5,
  },
  
  // 设置项样式
  settingItem: {
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E5E6EB',
    backgroundColor: '#ffffff',
  },
  
  settingItemContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  
  settingItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  
  settingItemText: {
    marginLeft: 12,
    flex: 1,
  },
  
  settingItemTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
    marginBottom: 2,
  },
  
  settingItemSubtitle: {
    fontSize: 12,
    color: '#4E5969',
  },
  
  settingLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
    marginBottom: 8,
  },
  
  // 时间窗设置
  timeWindowContainer: {
    gap: 8,
  },
  
  timeSelectorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  
  timeSelector: {
    flex: 1,
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#E5E6EB',
    borderRadius: 4,
    alignItems: 'center',
  },
  
  timeSelectorText: {
    fontSize: 14,
    color: '#333333',
  },
  
  timeSeparator: {
    fontSize: 14,
    color: '#4E5969',
  },
  
  // 节流设置
  throttleContainer: {
    gap: 8,
  },
  
  throttleInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  
  throttleInput: {
    flex: 1,
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#E5E6EB',
    borderRadius: 4,
    fontSize: 14,
    color: '#333333',
  },
  
  throttleUnit: {
    fontSize: 14,
    color: '#4E5969',
  },
  
  throttleDescription: {
    fontSize: 12,
    color: '#4E5969',
    lineHeight: 16,
  },
  
  // 延时范围
  delayRangeContainer: {
    gap: 8,
  },
  
  delayInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  
  delayInput: {
    width: 64,
    paddingHorizontal: 8,
    paddingVertical: 4,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#E5E6EB',
    borderRadius: 4,
    fontSize: 14,
    color: '#333333',
    textAlign: 'center',
  },
  
  delaySeparator: {
    fontSize: 14,
    color: '#4E5969',
  },
  
  delayUnit: {
    fontSize: 14,
    color: '#4E5969',
  },
  
  // 日志按钮
  logsButton: {
    padding: 12,
    borderRadius: 8,
    backgroundColor: '#F7F8FA',
  },
  
  logsButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  
  logsButtonLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  
  logsButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
    marginLeft: 12,
  },
  
  // 最近活动
  recentActivityContainer: {
    padding: 12,
    backgroundColor: '#F7F8FA',
    borderRadius: 8,
    gap: 8,
  },
  
  recentActivityTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
  },
  
  recentActivityList: {
    gap: 8,
  },
  
  recentActivityItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  
  recentActivityText: {
    fontSize: 12,
    color: '#4E5969',
    flex: 1,
  },
  
  recentActivityTime: {
    fontSize: 12,
    color: '#4E5969',
  },
  
  // 警告区域
  warningSection: {
    padding: 16,
    backgroundColor: '#FFFBEB',
    borderWidth: 1,
    borderColor: '#FDE68A',
    borderRadius: 8,
  },
  
  warningContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  
  warningTextContainer: {
    flex: 1,
    gap: 4,
  },
  
  warningTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#92400E',
  },
  
  warningDescription: {
    fontSize: 12,
    color: '#A16207',
    lineHeight: 18,
  },
});

