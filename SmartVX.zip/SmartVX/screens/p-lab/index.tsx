

import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, Switch, Alert, } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { FontAwesome5, FontAwesome6 } from '@expo/vector-icons';
import styles from './styles';

const LabScreen = () => {
  const router = useRouter();
  
  // 状态管理
  const [isAutoReplyEnabled, setIsAutoReplyEnabled] = useState(false);
  const [isRandomDelayEnabled, setIsRandomDelayEnabled] = useState(false);
  const [startTime, setStartTime] = useState('20:00');
  const [endTime, setEndTime] = useState('23:00');
  const [throttleMinutes, setThrottleMinutes] = useState('5');
  const [minDelay, setMinDelay] = useState('1');
  const [maxDelay, setMaxDelay] = useState('5');

  // 处理返回按钮
  const handleBackPress = () => {
    if (router.canGoBack()) {
      router.back();
    }
  };

  // 处理全自动回复开关
  const handleAutoReplyToggle = (value: boolean) => {
    if (value) {
      Alert.alert(
        '确认开启',
        '开启全自动回复后，AI将在指定时间内自动帮您回复消息。确定要开启吗？',
        [
          { text: '取消', style: 'cancel' },
          { 
            text: '确定', 
            onPress: () => {
              setIsAutoReplyEnabled(true);
              console.log('全自动回复已开启');
            }
          }
        ]
      );
    } else {
      setIsAutoReplyEnabled(false);
      console.log('全自动回复已关闭');
    }
  };

  // 处理联系人白名单
  const handleWhitelistPress = () => {
    if (!isAutoReplyEnabled) {
      Alert.alert('提示', '请先开启全自动回复功能');
      return;
    }
    console.log('跳转到联系人白名单选择页面');
    // 这里可以导航到联系人选择页面
    router.push('/p-object_list?mode=whitelist');
  };

  // 处理时间选择
  const handleTimeChange = (type: 'start' | 'end', value: string) => {
    if (type === 'start') {
      setStartTime(value);
    } else {
      setEndTime(value);
    }
    console.log(`时间窗已设置为：${startTime} - ${endTime}`);
  };

  // 处理节流设置
  const handleThrottleChange = (value: string) => {
    setThrottleMinutes(value);
    console.log(`节流设置已更新为：${value}分钟/会话`);
  };

  // 处理随机延时开关
  const handleRandomDelayToggle = (value: boolean) => {
    setIsRandomDelayEnabled(value);
    console.log(`随机延时已${value ? '开启' : '关闭'}`);
  };

  // 处理延时范围设置
  const handleDelayRangeChange = (type: 'min' | 'max', value: string) => {
    const numValue = parseInt(value) || 0;
    
    if (type === 'min') {
      if (numValue > parseInt(maxDelay)) {
        setMaxDelay(value);
      }
      setMinDelay(value);
    } else {
      if (numValue < parseInt(minDelay)) {
        setMinDelay(value);
      }
      setMaxDelay(value);
    }
    
    console.log(`延时范围已设置为：${minDelay} - ${maxDelay}秒`);
  };

  // 处理查看日志
  const handleViewLogsPress = () => {
    console.log('跳转到详细日志页面');
    Alert.alert('提示', '详细日志功能即将推出');
  };

  // 生成时间选项
  const generateTimeOptions = () => {
    const times = [];
    for (let i = 0; i < 24; i++) {
      const hour = i.toString().padStart(2, '0');
      times.push(`${hour}:00`);
    }
    return times;
  };

  const timeOptions = generateTimeOptions();

  return (
    <SafeAreaView style={styles.container}>
      {/* 顶部导航 */}
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={handleBackPress}
          activeOpacity={0.7}
        >
          <FontAwesome6 name="chevron-left" size={18} color="#374151" />
        </TouchableOpacity>
        <View style={styles.headerTitleContainer}>
          <Text style={styles.headerTitle}>实验室</Text>
          <View style={styles.betaBadge}>
            <Text style={styles.betaBadgeText}>Beta</Text>
          </View>
        </View>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <View style={styles.content}>
          {/* 全自动回复 */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <View style={styles.sectionHeaderInfo}>
                <Text style={styles.sectionTitle}>全自动回复</Text>
                <Text style={styles.sectionDescription}>让AI自动帮你回复消息</Text>
              </View>
              <Switch
                value={isAutoReplyEnabled}
                onValueChange={handleAutoReplyToggle}
                trackColor={{ false: '#e5e5e5', true: '#165DFF' }}
                thumbColor="#ffffff"
              />
            </View>
            
            <View style={[
              styles.sectionContent,
              !isAutoReplyEnabled && styles.disabledSection
            ]}>
              {/* 联系人白名单 */}
              <TouchableOpacity 
                style={styles.settingItem}
                onPress={handleWhitelistPress}
                activeOpacity={0.7}
                disabled={!isAutoReplyEnabled}
              >
                <View style={styles.settingItemContent}>
                  <View style={styles.settingItemLeft}>
                    <FontAwesome6 name="user-check" size={16} color="#165DFF" />
                    <View style={styles.settingItemText}>
                      <Text style={styles.settingItemTitle}>联系人白名单</Text>
                      <Text style={styles.settingItemSubtitle}>选择允许自动回复的联系人</Text>
                    </View>
                  </View>
                  <FontAwesome6 name="chevron-right" size={14} color="#86909C" />
                </View>
              </TouchableOpacity>
              
              {/* 时间窗 */}
              <View style={styles.timeWindowContainer}>
                <Text style={styles.settingLabel}>生效时间窗</Text>
                <View style={styles.timeSelectorContainer}>
                  <View style={styles.timeSelector}>
                    <Text style={styles.timeSelectorText}>{startTime}</Text>
                  </View>
                  <Text style={styles.timeSeparator}>-</Text>
                  <View style={styles.timeSelector}>
                    <Text style={styles.timeSelectorText}>{endTime}</Text>
                  </View>
                </View>
              </View>
              
              {/* 节流设置 */}
              <View style={styles.throttleContainer}>
                <Text style={styles.settingLabel}>节流设置</Text>
                <View style={styles.throttleInputContainer}>
                  <TextInput
                    style={styles.throttleInput}
                    value={throttleMinutes}
                    onChangeText={handleThrottleChange}
                    keyboardType="numeric"
                    placeholder="5"
                    placeholderTextColor="#999999"
                    editable={isAutoReplyEnabled}
                  />
                  <Text style={styles.throttleUnit}>分钟/会话</Text>
                </View>
                <Text style={styles.throttleDescription}>控制每会话的回复频率，避免过度打扰</Text>
              </View>
            </View>
          </View>

          {/* 随机延时 */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <View style={styles.sectionHeaderInfo}>
                <Text style={styles.sectionTitle}>随机延时</Text>
                <Text style={styles.sectionDescription}>让回复更自然，避免被察觉是AI</Text>
              </View>
              <Switch
                value={isRandomDelayEnabled}
                onValueChange={handleRandomDelayToggle}
                trackColor={{ false: '#e5e5e5', true: '#165DFF' }}
                thumbColor="#ffffff"
              />
            </View>
            
            <View style={[
              styles.sectionContent,
              !isRandomDelayEnabled && styles.disabledSection
            ]}>
              <View style={styles.delayRangeContainer}>
                <Text style={styles.settingLabel}>延时范围</Text>
                <View style={styles.delayInputContainer}>
                  <TextInput
                    style={styles.delayInput}
                    value={minDelay}
                    onChangeText={(value) => handleDelayRangeChange('min', value)}
                    keyboardType="numeric"
                    placeholder="1"
                    placeholderTextColor="#999999"
                    editable={isRandomDelayEnabled}
                  />
                  <Text style={styles.delaySeparator}>-</Text>
                  <TextInput
                    style={styles.delayInput}
                    value={maxDelay}
                    onChangeText={(value) => handleDelayRangeChange('max', value)}
                    keyboardType="numeric"
                    placeholder="5"
                    placeholderTextColor="#999999"
                    editable={isRandomDelayEnabled}
                  />
                  <Text style={styles.delayUnit}>秒</Text>
                </View>
              </View>
            </View>
          </View>

          {/* 日志与可解释性 */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <View style={styles.sectionHeaderInfo}>
                <Text style={styles.sectionTitle}>日志与可解释性</Text>
                <Text style={styles.sectionDescription}>查看AI决策过程和安全规则命中记录</Text>
              </View>
              <FontAwesome6 name="chart-line" size={18} color="#165DFF" />
            </View>
            
            <View style={styles.sectionContent}>
              <TouchableOpacity 
                style={styles.logsButton}
                onPress={handleViewLogsPress}
                activeOpacity={0.7}
              >
                <View style={styles.logsButtonContent}>
                  <View style={styles.logsButtonLeft}>
                    <FontAwesome5 name="list-alt" size={16} color="#165DFF" />
                    <Text style={styles.logsButtonText}>查看详细日志</Text>
                  </View>
                  <FontAwesome6 name="chevron-right" size={14} color="#86909C" />
                </View>
              </TouchableOpacity>
              
              <View style={styles.recentActivityContainer}>
                <Text style={styles.recentActivityTitle}>最近活动</Text>
                <View style={styles.recentActivityList}>
                  <View style={styles.recentActivityItem}>
                    <Text style={styles.recentActivityText}>暖心同学人设已应用</Text>
                    <Text style={styles.recentActivityTime}>2分钟前</Text>
                  </View>
                  <View style={styles.recentActivityItem}>
                    <Text style={styles.recentActivityText}>安全规则：检测到敏感词</Text>
                    <Text style={styles.recentActivityTime}>10分钟前</Text>
                  </View>
                  <View style={styles.recentActivityItem}>
                    <Text style={styles.recentActivityText}>自动回复：小雨 - 已发送</Text>
                    <Text style={styles.recentActivityTime}>1小时前</Text>
                  </View>
                </View>
              </View>
            </View>
          </View>

          {/* 实验性功能警告 */}
          <View style={styles.warningSection}>
            <View style={styles.warningContent}>
              <FontAwesome6 name="triangle-exclamation" size={16} color="#D97706" />
              <View style={styles.warningTextContainer}>
                <Text style={styles.warningTitle}>实验性功能警告</Text>
                <Text style={styles.warningDescription}>
                  实验室功能仍在开发中，可能存在不稳定或意外行为。请谨慎使用全自动回复等高级功能，避免对您的社交关系造成影响。
                </Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default LabScreen;

