

import React, { useState, useRef } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, Switch, Alert, Modal, FlatList, Image, Dimensions, } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { FontAwesome6 } from '@expo/vector-icons';
import styles from './styles';

const { width: screenWidth } = Dimensions.get('window');

interface Persona {
  id: string;
  name: string;
  description: string;
  usageCount: number;
  icon: string;
  isActive: boolean;
}

interface ChatObject {
  id: string;
  name: string;
  avatar: string;
  lastMessage: string;
  lastTime: string;
  adoptionRate: number;
  tagCount: number;
}

interface WhisperSuggestion {
  id: string;
  content: string;
}

const HomeScreen: React.FC = () => {
  const router = useRouter();
  
  // API连接状态
  const [accessMode, setAccessMode] = useState<string>('cloud');
  const [provider, setProvider] = useState<string>('openai');
  const [model, setModel] = useState<string>('gpt-3.5-turbo');
  const [apiKey, setApiKey] = useState<string>('sk-...');
  const [isTestingConnection, setIsTestingConnection] = useState<boolean>(false);
  const [connectionStatus, setConnectionStatus] = useState<string>('已连接');
  
  // 人设状态
  const [personas, setPersonas] = useState<Persona[]>([
    {
      id: 'warm-classmate',
      name: '暖心同学',
      description: '温柔体贴，善解人意',
      usageCount: 12,
      icon: 'heart',
      isActive: true,
    },
    {
      id: 'stable-colleague',
      name: '稳重同事',
      description: '专业严谨，条理清晰',
      usageCount: 8,
      icon: 'briefcase',
      isActive: false,
    },
    {
      id: 'energetic-friend',
      name: '元气伙伴',
      description: '活泼开朗，充满活力',
      usageCount: 6,
      icon: 'sun',
      isActive: false,
    },
  ]);
  
  // 最近聊天对象
  const [chatObjects, setChatObjects] = useState<ChatObject[]>([
    {
      id: 'object-1',
      name: '小雨',
      avatar: 'https://s.coze.cn/image/QvvS0qcQgsQ/',
      lastMessage: '周末想去看电影，有什么推荐吗？',
      lastTime: '2分钟前',
      adoptionRate: 85,
      tagCount: 3,
    },
    {
      id: 'object-2',
      name: '张总',
      avatar: 'https://s.coze.cn/image/eBYUbBCkR6I/',
      lastMessage: '关于项目进度的汇报',
      lastTime: '1小时前',
      adoptionRate: 92,
      tagCount: 5,
    },
    {
      id: 'object-3',
      name: '小美',
      avatar: 'https://s.coze.cn/image/eTzw4Vjgyq8/',
      lastMessage: '谢谢你的建议，很有用！',
      lastTime: '昨天',
      adoptionRate: 78,
      tagCount: 2,
    },
    {
      id: 'object-4',
      name: '王老师',
      avatar: 'https://s.coze.cn/image/pdqyV10zIx0/',
      lastMessage: '课程安排需要调整',
      lastTime: '2天前',
      adoptionRate: 88,
      tagCount: 4,
    },
    {
      id: 'object-5',
      name: '李医生',
      avatar: 'https://s.coze.cn/image/oAatVq14sgY/',
      lastMessage: '体检报告的注意事项',
      lastTime: '3天前',
      adoptionRate: 95,
      tagCount: 1,
    },
  ]);
  
  // 隐私设置
  const [localMemoryEnabled, setLocalMemoryEnabled] = useState<boolean>(true);
  const [cloudInferenceEnabled, setCloudInferenceEnabled] = useState<boolean>(true);
  const [isClearingCache, setIsClearingCache] = useState<boolean>(false);
  const [screenRecognitionEnabled, setScreenRecognitionEnabled] = useState<boolean>(true);
  const [showRecognitionOverlay, setShowRecognitionOverlay] = useState<boolean>(true);
  
  // 耳语助手
  const [whisperActive, setWhisperActive] = useState<boolean>(false);
  const [showWhisperOverlay, setShowWhisperOverlay] = useState<boolean>(false);
  const [whisperSuggestions] = useState<WhisperSuggestion[]>([
    {
      id: '1',
      content: '那太棒了！要不要一起去看最近上映的《流浪地球3》？听说口碑很不错。',
    },
    {
      id: '2',
      content: '我听说《你好,李焕英》重映了，你感兴趣吗？',
    },
    {
      id: '3',
      content: '好啊，你想看什么类型的？我可以帮你推荐几部。',
    },
  ]);
  
  // 底部弹出选择器
  const [showAccessModePicker, setShowAccessModePicker] = useState<boolean>(false);
  const [showProviderPicker, setShowProviderPicker] = useState<boolean>(false);
  const [showModelPicker, setShowModelPicker] = useState<boolean>(false);
  
  const accessModeOptions = [
    { label: '云端(Cloud)', value: 'cloud' },
    { label: '本地(Local)', value: 'local' },
  ];
  
  const providerOptions = accessMode === 'local' 
    ? [
        { label: 'Local GGUF', value: 'local-gguf' },
        { label: 'Local GGML', value: 'local-ggml' },
      ]
    : [
        { label: 'OpenAI', value: 'openai' },
        { label: 'SmartWX Cloud', value: 'smartwx' },
        { label: 'Anthropic Claude', value: 'claude' },
      ];
  
  const getModelOptions = () => {
    if (accessMode === 'local') {
      return [
        { label: 'Llama 2 7B Chat', value: 'llama-2-7b-chat' },
        { label: 'Mistral 7B Instruct', value: 'mistral-7b-instruct' },
        { label: 'Vicuna 7B v1.5', value: 'vicuna-7b-v1.5' },
      ];
    }
    
    switch (provider) {
      case 'openai':
        return [
          { label: 'gpt-3.5-turbo', value: 'gpt-3.5-turbo' },
          { label: 'gpt-4', value: 'gpt-4' },
          { label: 'gpt-4-turbo', value: 'gpt-4-turbo' },
        ];
      case 'claude':
        return [
          { label: 'Claude 2', value: 'claude-2' },
          { label: 'Claude 3 Sonnet', value: 'claude-3-sonnet' },
          { label: 'Claude 3 Haiku', value: 'claude-3-haiku' },
        ];
      case 'smartwx':
        return [
          { label: 'SmartWX 7B', value: 'smartwx-7b' },
          { label: 'SmartWX 13B', value: 'smartwx-13b' },
        ];
      default:
        return [
          { label: 'gpt-3.5-turbo', value: 'gpt-3.5-turbo' },
          { label: 'gpt-4', value: 'gpt-4' },
          { label: 'claude-2', value: 'claude-2' },
        ];
    }
  };
  
  const handleAccessModeChange = (value: string) => {
    setAccessMode(value);
    setProvider(accessMode === 'local' ? 'local-gguf' : 'openai');
    setModel(accessMode === 'local' ? 'llama-2-7b-chat' : 'gpt-3.5-turbo');
    setShowAccessModePicker(false);
  };
  
  const handleProviderChange = (value: string) => {
    setProvider(value);
    setShowProviderPicker(false);
  };
  
  const handleModelChange = (value: string) => {
    setModel(value);
    setShowModelPicker(false);
  };
  
  const handleTestConnection = async () => {
    setIsTestingConnection(true);
    try {
      // 模拟测试连接
      await new Promise(resolve => setTimeout(resolve, 1500));
      const delay = Math.floor(Math.random() * 200) + 100;
      setConnectionStatus(`已连接 (${delay}ms)`);
    } catch (error) {
      setConnectionStatus('连接失败');
    } finally {
      setIsTestingConnection(false);
    }
  };
  
  const handlePersonaSelect = (personaId: string) => {
    setPersonas(prev => prev.map(p => ({
      ...p,
      isActive: p.id === personaId,
    })));
  };
  
  const handleManagePersonas = () => {
    router.push('/p-persona_library');
  };
  
  const handleViewAllObjects = () => {
    router.push('/p-object_list');
  };
  
  const handleObjectPress = (objectId: string) => {
    router.push(`/p-object_detail?objectId=${objectId}`);
  };
  
  const handleLocalMemoryToggle = (value: boolean) => {
    if (!value) {
      Alert.alert(
        '确认关闭',
        '关闭本地记忆将影响AI建议的准确性，确定要关闭吗？',
        [
          { text: '取消', style: 'cancel' },
          { text: '确定', onPress: () => setLocalMemoryEnabled(false) },
        ]
      );
    } else {
      setLocalMemoryEnabled(value);
    }
  };
  
  const handleCloudInferenceToggle = (value: boolean) => {
    if (!value && accessMode === 'cloud') {
      Alert.alert(
        '确认关闭',
        '关闭云端推理将无法使用云端AI模型，建议切换到本地模式',
        [
          { text: '取消', style: 'cancel' },
          { text: '确定', onPress: () => setCloudInferenceEnabled(false) },
        ]
      );
    } else {
      setCloudInferenceEnabled(value);
    }
  };

  const handleScreenRecognitionToggle = (value: boolean) => {
    if (value) {
      Alert.alert(
        '启用屏幕识别',
        '开启后，应用将能够识别屏幕内容以提供无障碍输入。此功能仅在使用时激活，不会持续监控屏幕。',
        [
          { text: '取消', style: 'cancel' },
          { text: '确定', onPress: () => {
              setScreenRecognitionEnabled(true);
              setShowRecognitionOverlay(true);
            } 
          },
        ]
      );
    } else {
      setScreenRecognitionEnabled(value);
    }
  };
  
  const handleClearCache = async () => {
    setIsClearingCache(true);
    try {
      // 模拟清理缓存
      await new Promise(resolve => setTimeout(resolve, 1000));
      Alert.alert('成功', '缓存已清理');
    } catch (error) {
      Alert.alert('错误', '清理缓存失败');
    } finally {
      setIsClearingCache(false);
    }
  };
  
  const handleWhisperToggle = () => {
    setWhisperActive(!whisperActive);
    if (whisperActive) {
      setShowWhisperOverlay(false);
    } else {
      setShowWhisperOverlay(true);
    }
  };
  
  const handleWhisperBubblePress = () => {
    setShowWhisperOverlay(!showWhisperOverlay);
  };
  
  const handleWhisperClose = () => {
    setShowWhisperOverlay(false);
  };
  
  const handleWhisperInsert = (suggestion: WhisperSuggestion) => {
    Alert.alert('提示', '建议已插入到聊天输入框');
  };
  
  const handleWhisperCopy = (suggestion: WhisperSuggestion) => {
    Alert.alert('提示', '建议已复制到剪贴板');
  };
  
  const handleWhisperMore = () => {
    Alert.alert('提示', '更多语气功能开发中...');
  };
  
  const handleSettingsPress = () => {
    router.push('/p-settings');
  };
  
  const renderPickerModal = (
    visible: boolean,
    title: string,
    options: Array<{ label: string; value: string }>,
    onSelect: (value: string) => void,
    onClose: () => void
  ) => (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <View style={styles.modalOverlay}>
        <TouchableOpacity style={styles.modalBackdrop} onPress={onClose} />
        <View style={styles.pickerModal}>
          <View style={styles.pickerHeader}>
            <Text style={styles.pickerTitle}>{title}</Text>
            <TouchableOpacity onPress={onClose}>
              <FontAwesome6 name="xmark" size={20} color="#666" />
            </TouchableOpacity>
          </View>
          <FlatList
            data={options}
            keyExtractor={(item) => item.value}
            renderItem={({ item }) => (
              <TouchableOpacity
                style={styles.pickerOption}
                onPress={() => onSelect(item.value)}
              >
                <Text style={styles.pickerOptionText}>{item.label}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
      </View>
    </Modal>
  );
  
  const currentPersona = personas.find(p => p.isActive)?.name || '暖心同学';
  
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* 顶部导航 */}
        <View style={styles.header}>
          <View style={styles.appTitle}>
            <View style={styles.appIcon}>
              <FontAwesome6 name="comment-dots" size={16} color="#fff" />
            </View>
            <Text style={styles.appTitleText}>SmartVX</Text>
          </View>
          <TouchableOpacity style={styles.settingsButton} onPress={handleSettingsPress}>
            <FontAwesome6 name="gear" size={18} color="#333" />
          </TouchableOpacity>
        </View>
        
        {/* API接入卡 */}
        <View style={styles.apiCard}>
          <View style={styles.apiHeader}>
            <Text style={styles.apiTitle}>AI 连接设置</Text>
            <View style={styles.connectionStatus}>
              <View style={styles.statusDot} />
              <Text style={styles.statusText}>{connectionStatus}</Text>
            </View>
          </View>
          
          <View style={styles.apiConfig}>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>接入方式</Text>
              <TouchableOpacity
                style={styles.selectInput}
                onPress={() => setShowAccessModePicker(true)}
              >
                <Text style={styles.selectInputText}>
                  {accessModeOptions.find(opt => opt.value === accessMode)?.label}
                </Text>
                <FontAwesome6 name="chevron-down" size={12} color="#999" />
              </TouchableOpacity>
            </View>
            
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Provider</Text>
              <TouchableOpacity
                style={styles.selectInput}
                onPress={() => setShowProviderPicker(true)}
              >
                <Text style={styles.selectInputText}>
                  {providerOptions.find(opt => opt.value === provider)?.label}
                </Text>
                <FontAwesome6 name="chevron-down" size={12} color="#999" />
              </TouchableOpacity>
            </View>
            
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>模型</Text>
              <TouchableOpacity
                style={styles.selectInput}
                onPress={() => setShowModelPicker(true)}
              >
                <Text style={styles.selectInputText}>
                  {getModelOptions().find(opt => opt.value === model)?.label}
                </Text>
                <FontAwesome6 name="chevron-down" size={12} color="#999" />
              </TouchableOpacity>
            </View>
            
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>
                {accessMode === 'local' ? '模型路径' : 'API Key'}
              </Text>
              <TextInput
                style={styles.textInput}
                placeholder={accessMode === 'local' ? '/models/llama-2-7b-chat.gguf' : 'sk-...'}
                value={apiKey}
                onChangeText={setApiKey}
                secureTextEntry={accessMode !== 'local'}
              />
            </View>
            
            <TouchableOpacity
              style={[styles.testButton, isTestingConnection && styles.testButtonDisabled]}
              onPress={handleTestConnection}
              disabled={isTestingConnection}
            >
              <FontAwesome6 
                name={isTestingConnection ? "spinner" : "wifi"} 
                size={14} 
                color="#333" 
                style={isTestingConnection && styles.spinningIcon}
              />
              <Text style={styles.testButtonText}>
                {isTestingConnection ? '测试中...' : '测试连接'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        
        {/* 人设快捷区 */}
        <View style={styles.personaSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>最近使用人设</Text>
            <TouchableOpacity onPress={handleManagePersonas}>
              <View style={styles.manageButton}>
                <Text style={styles.manageButtonText}>管理全部</Text>
                <FontAwesome6 name="chevron-right" size={10} color="#666" />
              </View>
            </TouchableOpacity>
          </View>
          
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            style={styles.personaScrollView}
            contentContainerStyle={styles.personaScrollContent}
          >
            {personas.map((persona) => (
              <TouchableOpacity
                key={persona.id}
                style={[styles.personaCard, persona.isActive && styles.personaCardActive]}
                onPress={() => handlePersonaSelect(persona.id)}
              >
                <View style={styles.personaHeader}>
                  <View style={styles.personaIcon}>
                    <FontAwesome6 name={persona.icon} size={12} color="#165DFF" />
                  </View>
                  <Text style={styles.personaName}>{persona.name}</Text>
                </View>
                <Text style={styles.personaDescription}>{persona.description}</Text>
                <View style={styles.personaFooter}>
                  <Text style={styles.personaUsage}>使用 {persona.usageCount} 次</Text>
                  <Text style={[
                    styles.personaStatus,
                    persona.isActive ? styles.personaStatusActive : styles.personaStatusInactive
                  ]}>
                    {persona.isActive ? '当前' : '设为当前'}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        
        {/* 最近对象列表 */}
        <View style={styles.objectsSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>最近聊天对象</Text>
            <TouchableOpacity onPress={handleViewAllObjects}>
              <View style={styles.manageButton}>
                <Text style={styles.manageButtonText}>查看全部</Text>
                <FontAwesome6 name="chevron-right" size={10} color="#666" />
              </View>
            </TouchableOpacity>
          </View>
          
          <View style={styles.objectsList}>
            {chatObjects.map((object) => (
              <TouchableOpacity
                key={object.id}
                style={styles.objectItem}
                onPress={() => handleObjectPress(object.id)}
              >
                <View style={styles.objectContent}>
                  <Image source={{ uri: object.avatar }} style={styles.objectAvatar} />
                  <View style={styles.objectInfo}>
                    <View style={styles.objectHeader}>
                      <Text style={styles.objectName}>{object.name}</Text>
                      <Text style={styles.objectTime}>{object.lastTime}</Text>
                    </View>
                    <Text style={styles.objectMessage} numberOfLines={1}>
                      {object.lastMessage}
                    </Text>
                  </View>
                  <View style={styles.objectStats}>
                    <Text style={styles.objectAdoptionRate}>采纳率 {object.adoptionRate}%</Text>
                    <Text style={styles.objectTagCount}>{object.tagCount}个标签</Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>
        
        {/* 隐私与安全 */}
        <View style={styles.privacySection}>
          <View style={styles.privacyCard}>
            <Text style={styles.privacyTitle}>隐私与安全</Text>
            
            <View style={styles.privacySettings}>
              <View style={styles.settingItem}>
                <View style={styles.settingInfo}>
                  <Text style={styles.settingLabel}>本地记忆</Text>
                  <Text style={styles.settingDescription}>保存聊天历史以提供更好的建议</Text>
                </View>
                <Switch
                  value={localMemoryEnabled}
                  onValueChange={handleLocalMemoryToggle}
                  trackColor={{ false: '#e5e5e5', true: '#165DFF' }}
                  thumbColor="#fff"
                />
              </View>
              
              <View style={styles.settingItem}>
                <View style={styles.settingInfo}>
                  <Text style={styles.settingLabel}>云端推理</Text>
                  <Text style={styles.settingDescription}>使用云端AI模型进行推理</Text>
                </View>
                <Switch
                  value={cloudInferenceEnabled}
                  onValueChange={handleCloudInferenceToggle}
                  trackColor={{ false: '#e5e5e5', true: '#165DFF' }}
                  thumbColor="#fff"
                />
              </View>
              
              <View style={styles.settingItem}>
                <View style={styles.settingInfo}>
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <Text style={styles.settingLabel}>无障碍模式</Text>
                    <Text style={styles.requiredMark}> *</Text>
                  </View>
                  <Text style={styles.settingDescription}>必选项，保持开启以体验完整功能</Text>
                </View>
                <Switch
                  value={screenRecognitionEnabled}
                  onValueChange={handleScreenRecognitionToggle}
                  trackColor={{ false: '#e5e5e5', true: '#165DFF' }}
                  thumbColor="#fff"
                />
              </View>
              
              <View style={styles.privacyNote}>
                <Text style={styles.privacyNoteText}>
                  屏幕读取(OCR)仅用于解析聊天内容，不会存储原始截图
                </Text>
              </View>
              
              <TouchableOpacity
                style={[styles.clearButton, isClearingCache && styles.clearButtonDisabled]}
                onPress={handleClearCache}
                disabled={isClearingCache}
              >
                <FontAwesome6 
                  name={isClearingCache ? "spinner" : "trash-can"} 
                  size={14} 
                  color="#333" 
                  style={isClearingCache && styles.spinningIcon}
                />
                <Text style={styles.clearButtonText}>
                  {isClearingCache ? '清理中...' : '一键清理缓存'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        
        {/* 耳语开关 */}
        <View style={styles.whisperSection}>
          <TouchableOpacity
            style={[styles.whisperButton, whisperActive && styles.whisperButtonActive]}
            onPress={handleWhisperToggle}
          >
            <View style={styles.whisperButtonContent}>
              <FontAwesome6 
                name={whisperActive ? "microphone-slash" : "microphone"} 
                size={16} 
                color="#fff" 
              />
              <Text style={styles.whisperButtonText}>
                {whisperActive ? '关闭耳语助手' : '开启耳语助手'}
              </Text>
            </View>
            <Text style={styles.whisperPersonaText}>当前人设：{currentPersona}</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
      
      {/* 耳语浮层气泡 */}
      {whisperActive && (
        <>
          <TouchableOpacity
            style={styles.whisperBubble}
            onPress={handleWhisperBubblePress}
          >
            <FontAwesome6 name="comment-dots" size={18} color="#fff" />
          </TouchableOpacity>
          
          {/* 耳语展开卡片 */}
          {showWhisperOverlay && (
            <View style={styles.whisperOverlay}>
              <View style={styles.whisperOverlayHeader}>
                <Text style={styles.whisperOverlayTitle}>{currentPersona}</Text>
                <TouchableOpacity onPress={handleWhisperClose}>
                  <FontAwesome6 name="xmark" size={16} color="#999" />
                </TouchableOpacity>
              </View>
              
              <View style={styles.whisperSuggestions}>
                {whisperSuggestions.map((suggestion) => (
                  <View key={suggestion.id} style={styles.suggestionItem}>
                    <Text style={styles.suggestionText}>{suggestion.content}</Text>
                    <View style={styles.suggestionActions}>
                      <TouchableOpacity
                        style={styles.suggestionActionButton}
                        onPress={() => handleWhisperInsert(suggestion)}
                      >
                        <Text style={styles.suggestionActionText}>插入</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={styles.suggestionActionButtonSecondary}
                        onPress={() => handleWhisperCopy(suggestion)}
                      >
                        <Text style={styles.suggestionActionTextSecondary}>复制</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                ))}
              </View>
              
              <TouchableOpacity style={styles.whisperMoreButton} onPress={handleWhisperMore}>
                <Text style={styles.whisperMoreButtonText}>更多语气</Text>
              </TouchableOpacity>
            </View>
          )}
        </>
      )}
      
      {/* 屏幕识别提示浮层 */}
      {showRecognitionOverlay && (
        <View style={styles.recognitionOverlay}>
          <View style={styles.recognitionContent}>
            <FontAwesome6 name="check-circle" size={20} color="#22C55E" />
            <Text style={styles.recognitionText}>无障碍模式已启用</Text>
            <Text style={styles.recognitionSubText}>这是应用的必选功能，保持开启以体验完整功能</Text>
            <TouchableOpacity 
              style={styles.recognitionButton}
              onPress={() => setShowRecognitionOverlay(false)}
            >
              <Text style={styles.recognitionButtonText}>了解</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
      
      {/* 底部选择器模态框 */}
      {renderPickerModal(
        showAccessModePicker,
        '选择接入方式',
        accessModeOptions,
        handleAccessModeChange,
        () => setShowAccessModePicker(false)
      )}
      
      {renderPickerModal(
        showProviderPicker,
        '选择Provider',
        providerOptions,
        handleProviderChange,
        () => setShowProviderPicker(false)
      )}
      
      {renderPickerModal(
        showModelPicker,
        '选择模型',
        getModelOptions(),
        handleModelChange,
        () => setShowModelPicker(false)
      )}
    </SafeAreaView>
  );
};

export default HomeScreen;

