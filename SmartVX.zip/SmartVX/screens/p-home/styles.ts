

import { StyleSheet, Dimensions, Platform } from 'react-native';

const { width: screenWidth } = Dimensions.get('window');

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F3F5',
  },
  scrollView: {
    flex: 1,
  },
  
  // 顶部导航
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 16,
  },
  appTitle: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  appIcon: {
    width: 32,
    height: 32,
    backgroundColor: '#165DFF',
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  appTitleText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1D2129',
  },
  settingsButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(229, 230, 235, 0.5)',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
      },
      android: {
        elevation: 2,
      },
    }),
  },
  
  // API接入卡
  apiCard: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E5E6EB',
    borderRadius: 8,
    marginHorizontal: 24,
    padding: 20,
    marginBottom: 24,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
      },
      android: {
        elevation: 2,
      },
    }),
  },
  apiHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  apiTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1D2129',
  },
  connectionStatus: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusDot: {
    width: 8,
    height: 8,
    backgroundColor: '#22C55E',
    borderRadius: 4,
    marginRight: 8,
  },
  statusText: {
    fontSize: 14,
    color: '#4E5969',
  },
  apiConfig: {
    gap: 16,
  },
  inputGroup: {
    gap: 8,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
  },
  selectInput: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E5E6EB',
    borderRadius: 4,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 14,
    color: '#333333',
  },
  selectInputText: {
    fontSize: 14,
    color: '#333333',
  },
  textInput: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E5E6EB',
    borderRadius: 4,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 14,
    color: '#333333',
  },
  testButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F7F8FA',
    borderRadius: 4,
    paddingVertical: 12,
    gap: 8,
  },
  testButtonDisabled: {
    opacity: 0.6,
  },
  testButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
  },
  spinningIcon: {
    transform: [{ rotate: '45deg' }],
  },
  
  // 人设快捷区
  personaSection: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1D2129',
  },
  manageButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  manageButtonText: {
    fontSize: 14,
    color: '#4E5969',
  },
  personaScrollView: {
    paddingHorizontal: 24,
  },
  personaScrollContent: {
    gap: 16,
  },
  personaCard: {
    width: 160,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E5E6EB',
    borderRadius: 12,
    padding: 16,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
      },
      android: {
        elevation: 2,
      },
    }),
  },
  personaCardActive: {
    borderColor: '#165DFF',
    backgroundColor: 'rgba(22, 93, 255, 0.05)',
  },
  personaHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    gap: 8,
  },
  personaIcon: {
    width: 24,
    height: 24,
    backgroundColor: '#F7F8FA',
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  personaName: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
  },
  personaDescription: {
    fontSize: 12,
    color: '#4E5969',
    marginBottom: 12,
  },
  personaFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  personaUsage: {
    fontSize: 12,
    color: '#86909C',
  },
  personaStatus: {
    fontSize: 12,
    fontWeight: '500',
  },
  personaStatusActive: {
    color: '#165DFF',
  },
  personaStatusInactive: {
    color: 'rgba(22, 93, 255, 0.8)',
  },
  
  // 最近对象列表
  objectsSection: {
    marginBottom: 24,
  },
  objectsList: {
    paddingHorizontal: 24,
    gap: 12,
  },
  objectItem: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E5E6EB',
    borderRadius: 8,
    padding: 16,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 2,
      },
      android: {
        elevation: 1,
      },
    }),
  },
  objectContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  objectAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  objectInfo: {
    flex: 1,
    gap: 4,
  },
  objectHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  objectName: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1D2129',
  },
  objectTime: {
    fontSize: 12,
    color: '#86909C',
  },
  objectMessage: {
    fontSize: 14,
    color: '#4E5969',
  },
  objectStats: {
    alignItems: 'flex-end',
    gap: 2,
  },
  objectAdoptionRate: {
    fontSize: 12,
    color: '#22C55E',
  },
  objectTagCount: {
    fontSize: 12,
    color: '#86909C',
  },
  
  // 隐私与安全
  privacySection: {
    marginBottom: 24,
  },
  privacyCard: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E5E6EB',
    borderRadius: 8,
    marginHorizontal: 24,
    padding: 20,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
      },
      android: {
        elevation: 2,
      },
    }),
  },
  privacyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1D2129',
    marginBottom: 16,
  },
  privacySettings: {
    gap: 16,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  settingInfo: {
    flex: 1,
    marginRight: 16,
  },
  settingLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
    marginBottom: 4,
  },
  requiredMark: {
    fontSize: 14,
    fontWeight: '500',
    color: '#EF4444',
  },
  settingDescription: {
    fontSize: 12,
    color: '#86909C',
  },
  privacyNote: {
    backgroundColor: 'rgba(22, 93, 255, 0.05)',
    borderRadius: 6,
    padding: 12,
  },
  privacyNoteText: {
    fontSize: 14,
    color: '#4E5969',
    lineHeight: 20,
  },
  clearButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F7F8FA',
    borderRadius: 4,
    paddingVertical: 12,
    gap: 8,
  },
  clearButtonDisabled: {
    opacity: 0.6,
  },
  clearButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
  },
  
  // 耳语开关
  whisperSection: {
    marginBottom: 100,
    paddingHorizontal: 24,
  },
  whisperButton: {
    backgroundColor: '#165DFF',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    gap: 4,
    ...Platform.select({
      ios: {
        shadowColor: '#165DFF',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
      },
      android: {
        elevation: 4,
      },
    }),
  },
  whisperButtonActive: {
    backgroundColor: '#165DFF',
  },
  whisperButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  whisperButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  whisperPersonaText: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.9)',
  },
  
  // 耳语浮层
  whisperBubble: {
    position: 'absolute',
    bottom: 100,
    right: 20,
    width: 50,
    height: 50,
    backgroundColor: '#165DFF',
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    ...Platform.select({
      ios: {
        shadowColor: '#165DFF',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 12,
      },
      android: {
        elevation: 8,
      },
    }),
  },
  whisperOverlay: {
    position: 'absolute',
    bottom: 170,
    right: 20,
    width: 300,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.15,
        shadowRadius: 24,
      },
      android: {
        elevation: 12,
      },
    }),
  },
  whisperOverlayHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  whisperOverlayTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1D2129',
  },
  whisperSuggestions: {
    gap: 12,
    marginBottom: 16,
  },
  suggestionItem: {
    backgroundColor: '#F7F8FA',
    borderRadius: 8,
    padding: 12,
    gap: 8,
  },
  suggestionText: {
    fontSize: 14,
    color: '#1D2129',
    lineHeight: 20,
  },
  suggestionActions: {
    flexDirection: 'row',
    gap: 8,
  },
  suggestionActionButton: {
    backgroundColor: '#165DFF',
    borderRadius: 4,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  suggestionActionText: {
    fontSize: 12,
    color: '#FFFFFF',
    fontWeight: '500',
  },
  suggestionActionButtonSecondary: {
    backgroundColor: '#E5E6EB',
    borderRadius: 4,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  suggestionActionTextSecondary: {
    fontSize: 12,
    color: '#4E5969',
    fontWeight: '500',
  },
  whisperMoreButton: {
    borderWidth: 1,
    borderColor: '#165DFF',
    borderRadius: 4,
    paddingVertical: 12,
    alignItems: 'center',
  },
  whisperMoreButtonText: {
    fontSize: 14,
    color: '#165DFF',
    fontWeight: '500',
  },
  
  // 底部选择器模态框
  modalOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  modalBackdrop: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  pickerModal: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    maxHeight: '60%',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: -4 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
      },
      android: {
        elevation: 8,
      },
    }),
  },
  pickerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E6EB',
  },
  pickerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1D2129',
  },
  pickerOption: {
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F2F3F5',
  },
  pickerOptionText: {
    fontSize: 16,
    color: '#1D2129',
  },
  // 屏幕识别提示浮层
  recognitionOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  recognitionContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 24,
    width: '80%',
    alignItems: 'center',
    gap: 16,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 12,
      },
      android: {
        elevation: 8,
      },
    }),
  },
  recognitionText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1D2129',
    textAlign: 'center',
  },
  recognitionSubText: {
    fontSize: 14,
    color: '#4E5969',
    textAlign: 'center',
    lineHeight: 20,
  },
  recognitionButton: {
    backgroundColor: '#165DFF',
    borderRadius: 8,
    paddingHorizontal: 24,
    paddingVertical: 12,
    marginTop: 8,
  },
  recognitionButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#FFFFFF',
  },
});


