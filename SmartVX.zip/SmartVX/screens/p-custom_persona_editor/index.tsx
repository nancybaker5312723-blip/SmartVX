

import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, Switch, Alert, } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { FontAwesome6 } from '@expo/vector-icons';
import Slider from '@react-native-community/slider';
import styles from './styles';
import BottomSheetPicker from './components/BottomSheetPicker';

interface PersonaData {
  name: string;
  description: string;
  tone: {
    casual: number;
    humorous: number;
    polite: number;
    intimacy: number;
  };
  response: {
    length: string;
    emojiDensity: string;
  };
  special: {
    forbiddenWords: string[];
    mixedLanguage: boolean;
    invitationStrength: string;
    delayRemedy: string;
  };
}

const CustomPersonaEditor: React.FC = () => {
  const router = useRouter();
  const params = useLocalSearchParams();
  
  // 表单状态
  const [personaName, setPersonaName] = useState<string>('');
  const [personaDescription, setPersonaDescription] = useState<string>('');
  const [toneCasual, setToneCasual] = useState<number>(50);
  const [toneHumorous, setToneHumorous] = useState<number>(30);
  const [tonePolite, setTonePolite] = useState<number>(70);
  const [toneIntimacy, setToneIntimacy] = useState<number>(40);
  const [responseLength, setResponseLength] = useState<string>('medium');
  const [emojiDensity, setEmojiDensity] = useState<string>('medium');
  const [forbiddenWords, setForbiddenWords] = useState<string>('');
  const [mixedLanguage, setMixedLanguage] = useState<boolean>(true);
  const [invitationStrength, setInvitationStrength] = useState<string>('medium');
  const [delayRemedy, setDelayRemedy] = useState<string>('apology');
  
  // UI状态
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isResponseLengthPickerVisible, setIsResponseLengthPickerVisible] = useState<boolean>(false);
  const [isEmojiDensityPickerVisible, setIsEmojiDensityPickerVisible] = useState<boolean>(false);
  const [isInvitationStrengthPickerVisible, setIsInvitationStrengthPickerVisible] = useState<boolean>(false);
  const [isDelayRemedyPickerVisible, setIsDelayRemedyPickerVisible] = useState<boolean>(false);
  const [isToastVisible, setIsToastVisible] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string>('');

  // 选项数据
  const responseLengthOptions = [
    { label: '短（1-2句话）', value: 'short' },
    { label: '中（3-5句话）', value: 'medium' },
    { label: '长（6+句话）', value: 'long' },
  ];

  const emojiDensityOptions = [
    { label: '低（偶尔使用）', value: 'low' },
    { label: '中（适度使用）', value: 'medium' },
    { label: '高（频繁使用）', value: 'high' },
  ];

  const invitationStrengthOptions = [
    { label: '低（不主动邀约）', value: 'low' },
    { label: '中（适度邀约）', value: 'medium' },
    { label: '高（积极邀约）', value: 'high' },
  ];

  const delayRemedyOptions = [
    { label: '道歉优先', value: 'apology' },
    { label: '解释原因', value: 'explain' },
    { label: '转移话题', value: 'redirect' },
  ];

  // 显示Toast
  const showToast = (message: string) => {
    setToastMessage(message);
    setIsToastVisible(true);
    setTimeout(() => {
      setIsToastVisible(false);
    }, 2000);
  };

  // 验证表单
  const validateForm = (): boolean => {
    if (!personaName.trim()) {
      showToast('请输入人设名称');
      return false;
    }
    
    if (!personaDescription.trim()) {
      showToast('请输入风格描述');
      return false;
    }
    
    return true;
  };

  // 保存人设
  const handleSavePersona = async () => {
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    
    try {
      const personaData: PersonaData = {
        name: personaName.trim(),
        description: personaDescription.trim(),
        tone: {
          casual: toneCasual,
          humorous: toneHumorous,
          polite: tonePolite,
          intimacy: toneIntimacy,
        },
        response: {
          length: responseLength,
          emojiDensity: emojiDensity,
        },
        special: {
          forbiddenWords: forbiddenWords.trim().split(',').map(word => word.trim()).filter(word => word),
          mixedLanguage: mixedLanguage,
          invitationStrength: invitationStrength,
          delayRemedy: delayRemedy,
        },
      };

      // 模拟保存过程
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      console.log('保存人设数据:', personaData);
      showToast('人设已保存');
      
      setTimeout(() => {
        router.back();
      }, 1000);
      
    } catch (error) {
      showToast('保存失败，请重试');
    } finally {
      setIsLoading(false);
    }
  };

  // 处理返回
  const handleGoBack = () => {
    if (router.canGoBack()) {
      router.back();
    }
  };

  // 加载人设数据（编辑模式）
  const loadPersonaData = async (personaId: string) => {
    try {
      // 模拟加载已有数据
      const mockPersonaData: PersonaData = {
        name: '我的专属人设',
        description: '温柔体贴，善解人意的聊天伙伴',
        tone: {
          casual: 60,
          humorous: 40,
          polite: 80,
          intimacy: 50,
        },
        response: {
          length: 'medium',
          emojiDensity: 'medium',
        },
        special: {
          forbiddenWords: ['脏话', '敏感词'],
          mixedLanguage: true,
          invitationStrength: 'medium',
          delayRemedy: 'apology',
        },
      };

      setPersonaName(mockPersonaData.name);
      setPersonaDescription(mockPersonaData.description);
      setToneCasual(mockPersonaData.tone.casual);
      setToneHumorous(mockPersonaData.tone.humorous);
      setTonePolite(mockPersonaData.tone.polite);
      setToneIntimacy(mockPersonaData.tone.intimacy);
      setResponseLength(mockPersonaData.response.length);
      setEmojiDensity(mockPersonaData.response.emojiDensity);
      setForbiddenWords(mockPersonaData.special.forbiddenWords.join(', '));
      setMixedLanguage(mockPersonaData.special.mixedLanguage);
      setInvitationStrength(mockPersonaData.special.invitationStrength);
      setDelayRemedy(mockPersonaData.special.delayRemedy);
      
    } catch (error) {
      showToast('加载数据失败');
    }
  };

  // 初始化页面
  useEffect(() => {
    if (params.personaId) {
      loadPersonaData(params.personaId as string);
    }
  }, [params.personaId]);

  // 获取选项显示文本
  const getOptionLabel = (options: Array<{label: string, value: string}>, value: string): string => {
    const option = options.find(opt => opt.value === value);
    return option ? option.label : '';
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* 顶部导航 */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <TouchableOpacity 
            style={styles.backButton} 
            onPress={handleGoBack}
            activeOpacity={0.7}
          >
            <FontAwesome6 name="arrow-left" size={18} color="#374151" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>
            {params.personaId ? '编辑人设' : '新建人设'}
          </Text>
        </View>
        <TouchableOpacity 
          style={[styles.saveButton, isLoading && styles.saveButtonDisabled]} 
          onPress={handleSavePersona}
          disabled={isLoading}
          activeOpacity={0.8}
        >
          <Text style={styles.saveButtonText}>
            {isLoading ? '保存中...' : '保存'}
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* 基本信息 */}
        <View style={styles.section}>
          <View style={styles.card}>
            <Text style={styles.sectionTitle}>基本信息</Text>
            
            <View style={styles.formGroup}>
              <Text style={styles.label}>人设名称</Text>
              <TextInput
                style={styles.textInput}
                placeholder="为你的人设起个名字"
                placeholderTextColor="#999999"
                value={personaName}
                onChangeText={setPersonaName}
              />
            </View>
            
            <View style={styles.formGroup}>
              <Text style={styles.label}>风格描述</Text>
              <TextInput
                style={styles.textInput}
                placeholder="一句话描述这个人设的风格"
                placeholderTextColor="#999999"
                value={personaDescription}
                onChangeText={setPersonaDescription}
              />
            </View>
          </View>
        </View>

        {/* 语气设置 */}
        <View style={styles.section}>
          <View style={styles.card}>
            <Text style={styles.sectionTitle}>语气设置</Text>
            
            <View style={styles.sliderGroup}>
              <Text style={styles.label}>轻松程度</Text>
              <Slider
                style={styles.slider}
                minimumValue={0}
                maximumValue={100}
                value={toneCasual}
                onValueChange={setToneCasual}
                minimumTrackTintColor="#165DFF"
                maximumTrackTintColor="#E5E6EB"
                thumbTintColor="#FFFFFF"
              />
              <View style={styles.sliderLabels}>
                <Text style={styles.sliderLabelText}>严肃</Text>
                <Text style={styles.sliderLabelText}>轻松</Text>
              </View>
            </View>
            
            <View style={styles.sliderGroup}>
              <Text style={styles.label}>幽默程度</Text>
              <Slider
                style={styles.slider}
                minimumValue={0}
                maximumValue={100}
                value={toneHumorous}
                onValueChange={setToneHumorous}
                minimumTrackTintColor="#165DFF"
                maximumTrackTintColor="#E5E6EB"
                thumbTintColor="#FFFFFF"
              />
              <View style={styles.sliderLabels}>
                <Text style={styles.sliderLabelText}>正经</Text>
                <Text style={styles.sliderLabelText}>幽默</Text>
              </View>
            </View>
            
            <View style={styles.sliderGroup}>
              <Text style={styles.label}>礼貌程度</Text>
              <Slider
                style={styles.slider}
                minimumValue={0}
                maximumValue={100}
                value={tonePolite}
                onValueChange={setTonePolite}
                minimumTrackTintColor="#165DFF"
                maximumTrackTintColor="#E5E6EB"
                thumbTintColor="#FFFFFF"
              />
              <View style={styles.sliderLabels}>
                <Text style={styles.sliderLabelText}>直接</Text>
                <Text style={styles.sliderLabelText}>礼貌</Text>
              </View>
            </View>
            
            <View style={styles.sliderGroup}>
              <Text style={styles.label}>亲密度</Text>
              <Slider
                style={styles.slider}
                minimumValue={0}
                maximumValue={100}
                value={toneIntimacy}
                onValueChange={setToneIntimacy}
                minimumTrackTintColor="#165DFF"
                maximumTrackTintColor="#E5E6EB"
                thumbTintColor="#FFFFFF"
              />
              <View style={styles.sliderLabels}>
                <Text style={styles.sliderLabelText}>疏远</Text>
                <Text style={styles.sliderLabelText}>亲密</Text>
              </View>
            </View>
          </View>
        </View>

        {/* 回复设置 */}
        <View style={styles.section}>
          <View style={styles.card}>
            <Text style={styles.sectionTitle}>回复设置</Text>
            
            <TouchableOpacity 
              style={styles.pickerButton}
              onPress={() => setIsResponseLengthPickerVisible(true)}
              activeOpacity={0.7}
            >
              <Text style={styles.label}>回复长度</Text>
              <View style={styles.pickerRow}>
                <Text style={styles.pickerValue}>
                  {getOptionLabel(responseLengthOptions, responseLength)}
                </Text>
                <FontAwesome6 name="chevron-down" size={14} color="#6B7280" />
              </View>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.pickerButton}
              onPress={() => setIsEmojiDensityPickerVisible(true)}
              activeOpacity={0.7}
            >
              <Text style={styles.label}>Emoji密度</Text>
              <View style={styles.pickerRow}>
                <Text style={styles.pickerValue}>
                  {getOptionLabel(emojiDensityOptions, emojiDensity)}
                </Text>
                <FontAwesome6 name="chevron-down" size={14} color="#6B7280" />
              </View>
            </TouchableOpacity>
          </View>
        </View>

        {/* 特殊设置 */}
        <View style={styles.section}>
          <View style={styles.card}>
            <Text style={styles.sectionTitle}>特殊设置</Text>
            
            <View style={styles.formGroup}>
              <Text style={styles.label}>禁忌词</Text>
              <TextInput
                style={styles.textInput}
                placeholder="用逗号分隔，如：脏话,敏感词"
                placeholderTextColor="#999999"
                value={forbiddenWords}
                onChangeText={setForbiddenWords}
              />
            </View>
            
            <View style={styles.switchRow}>
              <View style={styles.switchInfo}>
                <Text style={styles.switchLabel}>英中混排</Text>
                <Text style={styles.switchDescription}>允许在回复中混合使用中英文</Text>
              </View>
              <Switch
                value={mixedLanguage}
                onValueChange={setMixedLanguage}
                trackColor={{ false: '#E5E5E5', true: '#165DFF' }}
                thumbColor="#FFFFFF"
              />
            </View>
            
            <TouchableOpacity 
              style={styles.pickerButton}
              onPress={() => setIsInvitationStrengthPickerVisible(true)}
              activeOpacity={0.7}
            >
              <Text style={styles.label}>邀约强度上限</Text>
              <View style={styles.pickerRow}>
                <Text style={styles.pickerValue}>
                  {getOptionLabel(invitationStrengthOptions, invitationStrength)}
                </Text>
                <FontAwesome6 name="chevron-down" size={14} color="#6B7280" />
              </View>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.pickerButton}
              onPress={() => setIsDelayRemedyPickerVisible(true)}
              activeOpacity={0.7}
            >
              <Text style={styles.label}>迟复补救偏好</Text>
              <View style={styles.pickerRow}>
                <Text style={styles.pickerValue}>
                  {getOptionLabel(delayRemedyOptions, delayRemedy)}
                </Text>
                <FontAwesome6 name="chevron-down" size={14} color="#6B7280" />
              </View>
            </TouchableOpacity>
          </View>
        </View>

        {/* 底部间距 */}
        <View style={styles.bottomSpacing} />
      </ScrollView>

      {/* Toast提示 */}
      {isToastVisible && (
        <View style={styles.toastContainer}>
          <View style={styles.toast}>
            <Text style={styles.toastText}>{toastMessage}</Text>
          </View>
        </View>
      )}

      {/* 底部选择器 */}
      <BottomSheetPicker
        visible={isResponseLengthPickerVisible}
        title="回复长度"
        options={responseLengthOptions}
        selectedValue={responseLength}
        onSelect={(value) => {
          setResponseLength(value);
          setIsResponseLengthPickerVisible(false);
        }}
        onClose={() => setIsResponseLengthPickerVisible(false)}
      />

      <BottomSheetPicker
        visible={isEmojiDensityPickerVisible}
        title="Emoji密度"
        options={emojiDensityOptions}
        selectedValue={emojiDensity}
        onSelect={(value) => {
          setEmojiDensity(value);
          setIsEmojiDensityPickerVisible(false);
        }}
        onClose={() => setIsEmojiDensityPickerVisible(false)}
      />

      <BottomSheetPicker
        visible={isInvitationStrengthPickerVisible}
        title="邀约强度上限"
        options={invitationStrengthOptions}
        selectedValue={invitationStrength}
        onSelect={(value) => {
          setInvitationStrength(value);
          setIsInvitationStrengthPickerVisible(false);
        }}
        onClose={() => setIsInvitationStrengthPickerVisible(false)}
      />

      <BottomSheetPicker
        visible={isDelayRemedyPickerVisible}
        title="迟复补救偏好"
        options={delayRemedyOptions}
        selectedValue={delayRemedy}
        onSelect={(value) => {
          setDelayRemedy(value);
          setIsDelayRemedyPickerVisible(false);
        }}
        onClose={() => setIsDelayRemedyPickerVisible(false)}
      />
    </SafeAreaView>
  );
};

export default CustomPersonaEditor;

