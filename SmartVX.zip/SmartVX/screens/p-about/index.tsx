

import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { FontAwesome6 } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import styles from './styles';

const AboutScreen = () => {
  const router = useRouter();

  const handleBackPress = () => {
    if (router.canGoBack()) {
      router.back();
    }
  };

  const handleUserAgreementPress = () => {
    Alert.alert('提示', '即将打开用户协议');
  };

  const handlePrivacyPolicyPress = () => {
    Alert.alert('提示', '即将打开隐私政策');
  };

  const handleOpenSourcePress = () => {
    Alert.alert('提示', '即将打开开源依赖列表');
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* 顶部导航 */}
        <View style={styles.header}>
          <TouchableOpacity 
            style={styles.backButton} 
            onPress={handleBackPress}
            activeOpacity={0.7}
          >
            <FontAwesome6 name="chevron-left" size={16} color="#374151" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>关于</Text>
        </View>

        {/* 应用信息卡片 */}
        <View style={styles.appInfoSection}>
          <LinearGradient
            colors={['#165DFF', '#4080FF']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.appInfoCard}
          >
            <View style={styles.appIcon}>
              <FontAwesome6 name="comment-dots" size={24} color="#FFFFFF" />
            </View>
            <Text style={styles.appName}>SmartVX</Text>
            <Text style={styles.appSubtitle}>SmartVX</Text>
            <View style={styles.versionInfo}>
              <Text style={styles.versionText}>版本 1.0.0</Text>
            </View>
          </LinearGradient>
        </View>

        {/* 功能列表 */}
        <View style={styles.functionListSection}>
          <View style={styles.functionList}>
            <TouchableOpacity 
              style={styles.listItem} 
              onPress={handleUserAgreementPress}
              activeOpacity={0.7}
            >
              <View style={styles.listItemContent}>
                <View style={styles.listItemLeft}>
                  <View style={styles.listItemIcon}>
                    <FontAwesome6 name="file-contract" size={14} color="#165DFF" />
                  </View>
                  <Text style={styles.listItemText}>用户协议</Text>
                </View>
                <FontAwesome6 name="chevron-right" size={12} color="#9CA3AF" />
              </View>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.listItem} 
              onPress={handlePrivacyPolicyPress}
              activeOpacity={0.7}
            >
              <View style={styles.listItemContent}>
                <View style={styles.listItemLeft}>
                  <View style={styles.listItemIcon}>
                    <FontAwesome6 name="shield-halved" size={14} color="#165DFF" />
                  </View>
                  <Text style={styles.listItemText}>隐私政策</Text>
                </View>
                <FontAwesome6 name="chevron-right" size={12} color="#9CA3AF" />
              </View>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={[styles.listItem, styles.lastListItem]} 
              onPress={handleOpenSourcePress}
              activeOpacity={0.7}
            >
              <View style={styles.listItemContent}>
                <View style={styles.listItemLeft}>
                  <View style={styles.listItemIcon}>
                    <FontAwesome6 name="github" size={14} color="#165DFF" />
                  </View>
                  <Text style={styles.listItemText}>开源依赖</Text>
                </View>
                <FontAwesome6 name="chevron-right" size={12} color="#9CA3AF" />
              </View>
            </TouchableOpacity>
          </View>
        </View>

        {/* 版权信息 */}
        <View style={styles.copyrightSection}>
          <Text style={styles.copyrightText}>© 2024 SmartVX团队</Text>
          <Text style={styles.copyrightSubtext}>让聊天更轻松，更有趣</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default AboutScreen;

