

import React, { useState, useRef } from 'react';
import { View, Text, TouchableOpacity, Modal, Dimensions, Alert, Platform, } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { FontAwesome6 } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import Animated, { useSharedValue, useAnimatedStyle, withTiming, withRepeat, withSequence, interpolate, } from 'react-native-reanimated';
import { GestureDetector, Gesture } from 'react-native-gesture-handler';
import * as Clipboard from 'expo-clipboard';
import styles from './styles';

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

type PersonaType = 'casual' | 'serious' | 'humorous' | 'polite';
type CardState = 'suggestions' | 'loading' | 'empty' | 'error';

interface SuggestionItem {
  id: string;
  text: string;
}

const PERSONA_CONFIG = {
  casual: {
    name: '轻松',
    color: 'rgba(255, 182, 193, 0.6)',
    iconColor: 'rgba(255, 182, 193, 1)',
  },
  serious: {
    name: '认真',
    color: 'rgba(173, 216, 230, 0.6)',
    iconColor: 'rgba(173, 216, 230, 1)',
  },
  humorous: {
    name: '幽默',
    color: 'rgba(255, 222, 173, 0.6)',
    iconColor: 'rgba(255, 222, 173, 1)',
  },
  polite: {
    name: '礼貌',
    color: 'rgba(221, 160, 221, 0.6)',
    iconColor: 'rgba(221, 160, 221, 1)',
  },
};

const SUGGESTIONS_DATA: SuggestionItem[] = [
  {
    id: '1',
    text: '那太棒了！要不要一起去看最近上映的《流浪地球3》？听说口碑很不错。',
  },
  {
    id: '2',
    text: '我听说《你好，李焕英》导演的新片也很好看，你感兴趣吗？',
  },
  {
    id: '3',
    text: '好啊，你想看什么类型的？我可以帮你推荐几部。',
  },
];

const WhisperOverlay: React.FC = () => {
  const router = useRouter();
  
  // 状态管理
  const [isCardExpanded, setIsCardExpanded] = useState(false);
  const [isMoreMenuVisible, setIsMoreMenuVisible] = useState(false);
  const [currentPersona, setCurrentPersona] = useState<PersonaType>('casual');
  const [cardState, setCardState] = useState<CardState>('suggestions');
  const [isConnected, setIsConnected] = useState(true);
  const [bubblePosition, setBubblePosition] = useState({ x: screenWidth - 80, y: screenHeight - 160 });

  // 动画值
  const cardTranslateY = useSharedValue(screenHeight);
  const backdropOpacity = useSharedValue(0);
  const moreMenuScale = useSharedValue(0.8);
  const moreMenuOpacity = useSharedValue(0);
  const loadingDot1 = useSharedValue(0);
  const loadingDot2 = useSharedValue(0);
  const loadingDot3 = useSharedValue(0);

  // 拖拽相关
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  // 初始化加载动画
  React.useEffect(() => {
    const loadingAnimation = withRepeat(
      withSequence(
        withTiming(1, { duration: 700 }),
        withTiming(0, { duration: 700 })
      ),
      -1,
      false
    );

    loadingDot1.value = loadingAnimation;
    loadingDot2.value = withTiming(0, { duration: 200 }, () => {
      loadingDot2.value = loadingAnimation;
    });
    loadingDot3.value = withTiming(0, { duration: 400 }, () => {
      loadingDot3.value = loadingAnimation;
    });
  }, []);

  // 气泡拖拽手势
  const panGesture = Gesture.Pan()
    .onBegin(() => {
      setIsDragging(true);
    })
    .onUpdate((event) => {
      if (isDragging) {
        const newX = Math.max(20, Math.min(event.absoluteX - dragOffset.x, screenWidth - 76));
        const newY = Math.max(20, Math.min(event.absoluteY - dragOffset.y, screenHeight - 76));
        setBubblePosition({ x: newX, y: newY });
      }
    })
    .onEnd(() => {
      setIsDragging(false);
    });

  // 气泡点击处理
  const handleBubblePress = () => {
    if (!isDragging) {
      toggleCard();
    }
  };

  // 切换卡片展开状态
  const toggleCard = () => {
    const newExpandedState = !isCardExpanded;
    setIsCardExpanded(newExpandedState);

    cardTranslateY.value = withTiming(newExpandedState ? 0 : screenHeight, {
      duration: 300,
    });

    backdropOpacity.value = withTiming(newExpandedState ? 1 : 0, {
      duration: 300,
    });

    if (newExpandedState) {
      // 模拟生成建议
      setCardState('loading');
      setTimeout(() => {
        setCardState('suggestions');
      }, 1500);
    } else {
      setIsMoreMenuVisible(false);
    }
  };

  // 背景点击处理
  const handleBackdropPress = () => {
    if (isCardExpanded) {
      toggleCard();
    }
  };

  // 更多菜单切换
  const toggleMoreMenu = () => {
    setIsMoreMenuVisible(!isMoreMenuVisible);
    moreMenuScale.value = withTiming(isMoreMenuVisible ? 0.8 : 1, {
      duration: 200,
    });
    moreMenuOpacity.value = withTiming(isMoreMenuVisible ? 0 : 1, {
      duration: 200,
    });
  };

  // 语气切换
  const handlePersonaChange = (persona: PersonaType) => {
    setCurrentPersona(persona);
    setIsMoreMenuVisible(false);
    
    // 重新生成建议
    setCardState('loading');
    setTimeout(() => {
      setCardState('suggestions');
    }, 1000);
  };

  // 插入建议
  const handleInsertSuggestion = (suggestion: SuggestionItem) => {
    // 模拟插入到聊天应用
    Alert.alert('提示', '已插入到输入框');
  };

  // 复制建议
  const handleCopySuggestion = async (suggestion: SuggestionItem) => {
    try {
      await Clipboard.setStringAsync(suggestion.text);
      Alert.alert('提示', '已复制到剪贴板');
    } catch (error) {
      Alert.alert('错误', '复制失败');
    }
  };

  // 前往设置
  const handleGoToSettings = () => {
    router.push('/p-settings');
  };

  // 动画样式
  const cardAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: cardTranslateY.value }],
  }));

  const backdropAnimatedStyle = useAnimatedStyle(() => ({
    opacity: backdropOpacity.value,
  }));

  const moreMenuAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: moreMenuScale.value }],
    opacity: moreMenuOpacity.value,
  }));

  const loadingDot1Style = useAnimatedStyle(() => ({
    transform: [{ scale: interpolate(loadingDot1.value, [0, 1], [0.3, 1]) }],
    opacity: interpolate(loadingDot1.value, [0, 0.5, 1], [0.5, 1, 0.5]),
  }));

  const loadingDot2Style = useAnimatedStyle(() => ({
    transform: [{ scale: interpolate(loadingDot2.value, [0, 1], [0.3, 1]) }],
    opacity: interpolate(loadingDot2.value, [0, 0.5, 1], [0.5, 1, 0.5]),
  }));

  const loadingDot3Style = useAnimatedStyle(() => ({
    transform: [{ scale: interpolate(loadingDot3.value, [0, 1], [0.3, 1]) }],
    opacity: interpolate(loadingDot3.value, [0, 0.5, 1], [0.5, 1, 0.5]),
  }));

  // 渲染建议项
  const renderSuggestionItem = (suggestion: SuggestionItem) => (
    <View key={suggestion.id} style={styles.suggestionItem}>
      <Text style={styles.suggestionText}>{suggestion.text}</Text>
      <View style={styles.suggestionActions}>
        <TouchableOpacity
          style={styles.insertButton}
          onPress={() => handleInsertSuggestion(suggestion)}
        >
          <Text style={styles.insertButtonText}>插入</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.copyButton}
          onPress={() => handleCopySuggestion(suggestion)}
        >
          <Text style={styles.copyButtonText}>复制</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  // 渲染卡片内容
  const renderCardContent = () => {
    switch (cardState) {
      case 'loading':
        return (
          <View style={styles.loadingState}>
            <View style={styles.loadingDots}>
              <Animated.View style={[styles.loadingDot, loadingDot1Style]} />
              <Animated.View style={[styles.loadingDot, loadingDot2Style]} />
              <Animated.View style={[styles.loadingDot, loadingDot3Style]} />
            </View>
            <Text style={styles.loadingText}>正在为您生成回复建议...</Text>
          </View>
        );
      case 'empty':
        return (
          <View style={styles.emptyState}>
            <FontAwesome6 name="comment-slash" size={48} color="#E5E6EB" />
            <Text style={styles.emptyText}>开始在微信输入框里打字试试</Text>
            <Text style={styles.emptySubText}>我会为您提供智能回复建议</Text>
          </View>
        );
      case 'error':
        return (
          <View style={styles.errorState}>
            <FontAwesome6 name="triangle-exclamation" size={48} color="#FF8C00" />
            <Text style={styles.errorText}>模型连接异常</Text>
            <Text style={styles.errorSubText}>请检查API配置或切换连接方式</Text>
            <TouchableOpacity style={styles.settingsButton} onPress={handleGoToSettings}>
              <Text style={styles.settingsButtonText}>前往设置</Text>
            </TouchableOpacity>
          </View>
        );
      default:
        return (
          <View style={styles.suggestionsContainer}>
            {SUGGESTIONS_DATA.map(renderSuggestionItem)}
          </View>
        );
    }
  };

  const currentPersonaConfig = PERSONA_CONFIG[currentPersona];

  return (
    <SafeAreaView style={styles.container}>
      {/* 背景遮罩 */}
      <Animated.View style={[styles.backdrop, backdropAnimatedStyle]}>
        <TouchableOpacity
          style={styles.backdropTouchable}
          activeOpacity={1}
          onPress={handleBackdropPress}
        />
      </Animated.View>

      {/* 耳语气泡 */}
      <GestureDetector gesture={panGesture}>
        <Animated.View
          style={[
            styles.bubble,
            {
              backgroundColor: currentPersonaConfig.color,
              left: bubblePosition.x,
              top: bubblePosition.y,
            },
          ]}
        >
          <View
            style={[
              styles.statusIndicator,
              isConnected ? styles.statusConnected : styles.statusDisconnected,
            ]}
          />
          <TouchableOpacity
            style={styles.bubbleContent}
            onPress={handleBubblePress}
            activeOpacity={0.8}
          >
            <FontAwesome6 name="comment-dots" size={18} color="#FFFFFF" />
          </TouchableOpacity>
        </Animated.View>
      </GestureDetector>

      {/* 耳语卡片 */}
      <Animated.View style={[styles.card, cardAnimatedStyle]}>
        {/* 卡片头部 */}
        <View style={styles.cardHeader}>
          <View style={styles.cardHeaderLeft}>
            <FontAwesome6
              name="comment-dots"
              size={18}
              color={currentPersonaConfig.iconColor}
            />
            <Text style={styles.cardTitle}>耳语助手</Text>
            <View
              style={[
                styles.personaIndicator,
                { backgroundColor: currentPersonaConfig.iconColor },
              ]}
            />
          </View>
          <TouchableOpacity
            style={styles.moreButton}
            onPress={toggleMoreMenu}
            activeOpacity={0.7}
          >
            <FontAwesome6 name="ellipsis-vertical" size={14} color="#4E5969" />
          </TouchableOpacity>
        </View>

        {/* 更多菜单 */}
        {isMoreMenuVisible && (
          <Animated.View style={[styles.moreMenu, moreMenuAnimatedStyle]}>
            {Object.entries(PERSONA_CONFIG).map(([key, config]) => (
              <TouchableOpacity
                key={key}
                style={styles.personaOption}
                onPress={() => handlePersonaChange(key as PersonaType)}
                activeOpacity={0.7}
              >
                <Text style={styles.personaOptionText}>{config.name}</Text>
              </TouchableOpacity>
            ))}
          </Animated.View>
        )}

        {/* 卡片内容 */}
        {renderCardContent()}

        {/* 卡片底部 */}
        <View style={styles.cardFooter}>
          <Text style={styles.cardFooterText}>基于AI生成的建议</Text>
          <Text style={styles.responseTimeText}>响应时间: 0.5s</Text>
        </View>
      </Animated.View>
    </SafeAreaView>
  );
};

export default WhisperOverlay;

