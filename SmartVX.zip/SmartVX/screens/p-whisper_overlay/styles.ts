

import { StyleSheet, Dimensions, Platform } from 'react-native';

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  backdrop: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.15)',
    zIndex: 998,
  },
  backdropTouchable: {
    flex: 1,
  },
  bubble: {
    position: 'absolute',
    width: 56,
    height: 56,
    borderRadius: 28,
    zIndex: 1000,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.15,
        shadowRadius: 12,
      },
      android: {
        elevation: 8,
      },
    }),
  },
  statusIndicator: {
    position: 'absolute',
    top: -2,
    right: -2,
    width: 8,
    height: 8,
    borderRadius: 4,
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  statusConnected: {
    backgroundColor: '#52C41A',
  },
  statusDisconnected: {
    backgroundColor: '#FF4D4F',
  },
  bubbleContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    maxWidth: 400,
    alignSelf: 'center',
    width: '100%',
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 24,
    zIndex: 999,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: -8 },
        shadowOpacity: 0.1,
        shadowRadius: 24,
      },
      android: {
        elevation: 16,
      },
    }),
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  cardHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1D2129',
  },
  personaIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  moreButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F7F8FA',
    justifyContent: 'center',
    alignItems: 'center',
  },
  moreMenu: {
    position: 'absolute',
    top: 64,
    right: 24,
    width: 128,
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    paddingVertical: 8,
    zIndex: 1001,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.15,
        shadowRadius: 12,
      },
      android: {
        elevation: 8,
      },
    }),
  },
  personaOption: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  personaOptionText: {
    fontSize: 14,
    color: '#1D2129',
  },
  suggestionsContainer: {
    gap: 12,
  },
  suggestionItem: {
    borderWidth: 1,
    borderColor: '#E5E6EB',
    borderRadius: 8,
    padding: 12,
  },
  suggestionText: {
    fontSize: 14,
    color: '#1D2129',
    lineHeight: 20,
    marginBottom: 12,
  },
  suggestionActions: {
    flexDirection: 'row',
    gap: 8,
  },
  insertButton: {
    backgroundColor: '#165DFF',
    borderWidth: 1,
    borderColor: '#165DFF',
    borderRadius: 4,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  insertButtonText: {
    fontSize: 12,
    fontWeight: '500',
    color: '#FFFFFF',
  },
  copyButton: {
    backgroundColor: '#F7F8FA',
    borderWidth: 1,
    borderColor: '#E5E6EB',
    borderRadius: 4,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  copyButtonText: {
    fontSize: 12,
    fontWeight: '500',
    color: '#4E5969',
  },
  loadingState: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  loadingDots: {
    flexDirection: 'row',
    gap: 2,
    marginBottom: 8,
  },
  loadingDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#86909C',
  },
  loadingText: {
    fontSize: 14,
    color: '#4E5969',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyText: {
    fontSize: 14,
    color: '#4E5969',
    marginTop: 16,
    marginBottom: 4,
  },
  emptySubText: {
    fontSize: 12,
    color: '#86909C',
  },
  errorState: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  errorText: {
    fontSize: 14,
    color: '#4E5969',
    marginTop: 16,
    marginBottom: 8,
  },
  errorSubText: {
    fontSize: 12,
    color: '#86909C',
    marginBottom: 16,
    textAlign: 'center',
  },
  settingsButton: {
    backgroundColor: '#165DFF',
    borderWidth: 1,
    borderColor: '#165DFF',
    borderRadius: 4,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  settingsButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#FFFFFF',
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 24,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#E5E6EB',
  },
  cardFooterText: {
    fontSize: 12,
    color: '#86909C',
  },
  responseTimeText: {
    fontSize: 12,
    color: '#86909C',
  },
});

