

import React from 'react';
import { View, Text, TouchableOpacity, Image } from 'react-native';
import { ObjectItemProps } from '../../types';
import styles from './styles';

const ObjectItem: React.FC<ObjectItemProps> = ({ object, onPress }) => {
  // 获取采纳率样式类
  const getAdoptionRateStyle = (rate: number) => {
    if (rate >= 80) return styles.rateHigh;
    if (rate >= 60) return styles.rateMedium;
    return styles.rateLow;
  };

  return (
    <TouchableOpacity
      style={styles.container}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={styles.content}>
        <Image
          source={{ uri: object.avatar }}
          style={styles.avatar}
          resizeMode="cover"
        />
        <View style={styles.info}>
          <View style={styles.header}>
            <Text style={styles.name}>{object.name}</Text>
            <View style={styles.badges}>
              <View style={[styles.adoptionRate, getAdoptionRateStyle(object.adoptionRate)]}>
                <Text style={styles.adoptionRateText}>{object.adoptionRate}%</Text>
              </View>
              <View style={styles.personaBadge}>
                <Text style={styles.personaBadgeText}>{object.persona}</Text>
              </View>
            </View>
          </View>
          <Text style={styles.lastMessage} numberOfLines={1}>
            {object.lastMessage}
          </Text>
          <View style={styles.footer}>
            <Text style={styles.time}>{object.time}</Text>
            <Text style={styles.interactions}>互动 {object.interactions} 次</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default ObjectItem;

