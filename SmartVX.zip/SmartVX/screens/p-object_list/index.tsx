

import React, { useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, TextInput, FlatList, RefreshControl, Modal, Alert, } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { FontAwesome6 } from '@expo/vector-icons';
import styles from './styles';
import ObjectItem from './components/ObjectItem';
import { ObjectData, SortType } from './types';

const ObjectListScreen = () => {
  const router = useRouter();
  
  // 原始对象数据
  const originalObjects: ObjectData[] = [
    {
      id: 'obj_001',
      name: '小雨',
      avatar: 'https://s.coze.cn/image/tQNWV-3EG3E/',
      lastMessage: '周末想去看电影，有什么推荐吗？',
      time: '2分钟前',
      adoptionRate: 92,
      persona: '暖心同学',
      interactions: 45,
      lastInteraction: new Date(Date.now() - 2 * 60 * 1000)
    },
    {
      id: 'obj_002',
      name: '张总',
      avatar: 'https://s.coze.cn/image/fhzs39FcZ7Q/',
      lastMessage: '关于项目进度的汇报',
      time: '1小时前',
      adoptionRate: 78,
      persona: '稳重同事',
      interactions: 23,
      lastInteraction: new Date(Date.now() - 60 * 60 * 1000)
    },
    {
      id: 'obj_003',
      name: '小美',
      avatar: 'https://s.coze.cn/image/lVsOHpweMpo/',
      lastMessage: '谢谢你的建议，很有用！',
      time: '昨天',
      adoptionRate: 85,
      persona: '元气伙伴',
      interactions: 67,
      lastInteraction: new Date(Date.now() - 24 * 60 * 60 * 1000)
    },
    {
      id: 'obj_004',
      name: '李老师',
      avatar: 'https://s.coze.cn/image/gWoXflbgPj8/',
      lastMessage: '作业什么时候交？',
      time: '3天前',
      adoptionRate: 65,
      persona: '专业助理',
      interactions: 12,
      lastInteraction: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000)
    },
    {
      id: 'obj_005',
      name: '妈妈',
      avatar: 'https://s.coze.cn/image/lVMekTCYHYM/',
      lastMessage: '记得按时吃饭，注意身体',
      time: '1周前',
      adoptionRate: 95,
      persona: '暖心同学',
      interactions: 89,
      lastInteraction: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    },
    {
      id: 'obj_006',
      name: '王同学',
      avatar: 'https://s.coze.cn/image/jWfvoPJFv3M/',
      lastMessage: '明天一起去图书馆吧',
      time: '2周前',
      adoptionRate: 45,
      persona: '元气伙伴',
      interactions: 8,
      lastInteraction: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000)
    }
  ];

  const [isSearchExpanded, setIsSearchExpanded] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSortMenuVisible, setIsSortMenuVisible] = useState(false);
  const [currentSort, setCurrentSort] = useState<SortType>('recent');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [filteredObjects, setFilteredObjects] = useState<ObjectData[]>(originalObjects);

  // 筛选和排序对象
  const filterAndSortObjects = useCallback(() => {
    let filtered = [...originalObjects];

    // 搜索筛选
    if (searchQuery) {
      filtered = filtered.filter(obj => 
        obj.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        obj.lastMessage.toLowerCase().includes(searchQuery.toLowerCase()) ||
        obj.persona.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // 排序
    switch (currentSort) {
      case 'recent':
        filtered.sort((a, b) => b.lastInteraction.getTime() - a.lastInteraction.getTime());
        break;
      case 'adoption':
        filtered.sort((a, b) => b.adoptionRate - a.adoptionRate);
        break;
      case 'frequency':
        filtered.sort((a, b) => b.interactions - a.interactions);
        break;
    }

    setFilteredObjects(filtered);
  }, [searchQuery, currentSort]);

  // 处理搜索按钮点击
  const handleSearchPress = () => {
    setIsSearchExpanded(!isSearchExpanded);
    if (isSearchExpanded) {
      setSearchQuery('');
    }
  };

  // 处理排序按钮点击
  const handleSortPress = () => {
    setIsSortMenuVisible(!isSortMenuVisible);
  };

  // 处理排序选项选择
  const handleSortOptionPress = (sortType: SortType) => {
    setCurrentSort(sortType);
    setIsSortMenuVisible(false);
  };

  // 处理对象项点击
  const handleObjectItemPress = (objectId: string) => {
    router.push(`/p-object_detail?objectId=${objectId}`);
  };

  // 处理下拉刷新
  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    try {
      // 模拟刷新延迟
      await new Promise(resolve => setTimeout(resolve, 1000));
      filterAndSortObjects();
    } catch (error) {
      Alert.alert('刷新失败', '请检查网络连接后重试');
    } finally {
      setIsRefreshing(false);
    }
  }, [filterAndSortObjects]);

  // 获取排序标签
  const getSortLabel = (sortType: SortType): string => {
    switch (sortType) {
      case 'recent': return '最近';
      case 'adoption': return '采纳率';
      case 'frequency': return '互动频次';
      default: return '最近';
    }
  };

  // 渲染排序菜单项
  const renderSortMenuItem = ({ item }: { item: SortType }) => (
    <TouchableOpacity
      style={[
        styles.sortMenuItem,
        currentSort === item && styles.sortMenuItemActive
      ]}
      onPress={() => handleSortOptionPress(item)}
    >
      <Text style={[
        styles.sortMenuItemText,
        currentSort === item && styles.sortMenuItemTextActive
      ]}>
        {getSortLabel(item)}
      </Text>
    </TouchableOpacity>
  );

  // 渲染空状态
  const renderEmptyState = () => (
    <View style={styles.emptyState}>
      <View style={styles.emptyStateIcon}>
        <FontAwesome6 name="address-book" size={32} color="#9CA3AF" />
      </View>
      <Text style={styles.emptyStateTitle}>暂无联系人</Text>
      <Text style={styles.emptyStateSubtitle}>开始使用耳语助手，记录你的聊天对象</Text>
    </View>
  );

  // 渲染列表头部
  const renderListHeader = () => (
    <View>
      {/* 搜索框 */}
      {isSearchExpanded && (
        <View style={styles.searchContainer}>
          <TextInput
            style={styles.searchInput}
            placeholder="搜索联系人..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            autoFocus
            placeholderTextColor="#999999"
          />
        </View>
      )}
    </View>
  );

  // 渲染对象项
  const renderObjectItem = ({ item }: { item: ObjectData }) => (
    <ObjectItem
      object={item}
      onPress={() => handleObjectItemPress(item.id)}
    />
  );

  // 监听搜索查询和排序变化
  React.useEffect(() => {
    filterAndSortObjects();
  }, [filterAndSortObjects]);

  return (
    <SafeAreaView style={styles.container}>
      {/* 顶部导航 */}
      <View style={styles.header}>
        <View style={styles.titleContainer}>
          <Text style={styles.title}>对象</Text>
        </View>
        <View style={styles.headerActions}>
          <TouchableOpacity
            style={styles.headerButton}
            onPress={handleSearchPress}
          >
            <FontAwesome6 name="magnifying-glass" size={16} color="#6B7280" />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.headerButton}
            onPress={handleSortPress}
          >
            <FontAwesome6 name="sort" size={16} color="#6B7280" />
          </TouchableOpacity>
        </View>
      </View>

      {/* 对象列表 */}
      <FlatList
        data={filteredObjects}
        renderItem={renderObjectItem}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={renderListHeader}
        ListEmptyComponent={renderEmptyState}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            colors={['#165DFF']}
            tintColor="#165DFF"
          />
        }
      />

      {/* 排序菜单模态框 */}
      <Modal
        visible={isSortMenuVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setIsSortMenuVisible(false)}
      >
        <TouchableOpacity
          style={styles.sortMenuOverlay}
          activeOpacity={1}
          onPress={() => setIsSortMenuVisible(false)}
        >
          <View style={styles.sortMenu}>
            <FlatList
              data={['recent', 'adoption', 'frequency'] as SortType[]}
              renderItem={renderSortMenuItem}
              keyExtractor={(item) => item}
              showsVerticalScrollIndicator={false}
            />
          </View>
        </TouchableOpacity>
      </Modal>
    </SafeAreaView>
  );
};

export default ObjectListScreen;

