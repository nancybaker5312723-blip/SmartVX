

export interface ObjectData {
  id: string;
  name: string;
  avatar: string;
  lastMessage: string;
  time: string;
  adoptionRate: number;
  persona: string;
  interactions: number;
  lastInteraction: Date;
}

export type SortType = 'recent' | 'adoption' | 'frequency';

export interface ObjectItemProps {
  object: ObjectData;
  onPress: () => void;
}

